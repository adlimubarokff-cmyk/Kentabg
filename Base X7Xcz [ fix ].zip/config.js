module.exports = {
  BOT_TOKEN: "ISI TOKEN",
  OWNER_ID: ["8154399997"],
};